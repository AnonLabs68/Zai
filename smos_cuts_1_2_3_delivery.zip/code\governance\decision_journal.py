"""
SMOS V18 — CUT 1 / L6 DECISION JOURNAL (v0)
=============================================
The memory organ: every governance decision is logged with its full state
vector, the rule that fired, the expected outcome, and — later — the
realized outcome. This makes ORGAN performance measurable, not just trade
performance (COGNITIVE_STACK_SPEC.md v1.1 §9).

Design law (B5): append-only. Decisions are never mutated; outcomes are
resolved as NEW rows in decision_outcomes referencing the decision's
event_id. No UPDATE path exists in the API.

Integration target:
  sovereign_fleet/governance/decision_journal.py  (verbatim)
  Consumed by AdmissionCommittee now; SentinelGrid / breakers later.

Stdlib only. Zero fleet dependencies.
"""

from __future__ import annotations

import json
import sqlite3
import time
from typing import Dict, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS decision_journal (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts_ns INTEGER NOT NULL,
    corridor TEXT NOT NULL,
    organ TEXT NOT NULL,
    state_vector TEXT NOT NULL,
    action TEXT NOT NULL,
    rule_id TEXT NOT NULL,
    expected_outcome TEXT
);
CREATE TABLE IF NOT EXISTS decision_outcomes (
    outcome_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL REFERENCES decision_journal(event_id),
    ts_ns INTEGER NOT NULL,
    outcome_bps REAL,
    outcome_usd REAL,
    verdict TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_dj_corridor ON decision_journal(corridor, ts_ns);
"""


class DecisionJournal:
    """Append-only organ-decision ledger."""

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.executescript(SCHEMA)

    # -- write (append-only) ------------------------------------------------
    def record_decision(self, corridor: str, organ: str,
                        state_vector: Dict, action: str, rule_id: str,
                        expected_outcome: Optional[str] = None) -> int:
        if not organ or not rule_id:
            raise ValueError("organ and rule_id are mandatory (journal law)")
        cur = self.conn.execute(
            "INSERT INTO decision_journal "
            "(ts_ns, corridor, organ, state_vector, action, rule_id, "
            " expected_outcome) VALUES (?,?,?,?,?,?,?)",
            (time.time_ns(), corridor, organ,
             json.dumps(state_vector, sort_keys=True, default=str),
             action, rule_id, expected_outcome))
        self.conn.commit()
        return cur.lastrowid

    def resolve_outcome(self, event_id: int, verdict: str,
                        outcome_bps: Optional[float] = None,
                        outcome_usd: Optional[float] = None) -> int:
        exists = self.conn.execute(
            "SELECT 1 FROM decision_journal WHERE event_id=?",
            (event_id,)).fetchone()
        if exists is None:
            raise KeyError(f"no decision event {event_id} to resolve")
        already = self.conn.execute(
            "SELECT COUNT(*) FROM decision_outcomes WHERE event_id=?",
            (event_id,)).fetchone()[0]
        if already:
            raise RuntimeError(
                f"decision {event_id} already resolved — outcomes are "
                f"append-only; open a NEW decision event instead (B5)")
        cur = self.conn.execute(
            "INSERT INTO decision_outcomes "
            "(event_id, ts_ns, outcome_bps, outcome_usd, verdict) "
            "VALUES (?,?,?,?,?)",
            (event_id, time.time_ns(), outcome_bps, outcome_usd, verdict))
        self.conn.commit()
        return cur.lastrowid

    # -- read ----------------------------------------------------------------
    def get_decision(self, event_id: int) -> Dict:
        row = self.conn.execute(
            "SELECT event_id, ts_ns, corridor, organ, state_vector, action, "
            "rule_id, expected_outcome FROM decision_journal "
            "WHERE event_id=?", (event_id,)).fetchone()
        if row is None:
            raise KeyError(event_id)
        return {
            "event_id": row[0], "ts_ns": row[1], "corridor": row[2],
            "organ": row[3], "state_vector": json.loads(row[4]),
            "action": row[5], "rule_id": row[6],
            "expected_outcome": row[7],
        }

    def decisions_for(self, corridor: str,
                      organ: Optional[str] = None) -> list:
        q = ("SELECT event_id FROM decision_journal WHERE corridor=?")
        args = [corridor]
        if organ:
            q += " AND organ=?"
            args.append(organ)
        q += " ORDER BY ts_ns ASC"
        return [self.get_decision(r[0])
                for r in self.conn.execute(q, args).fetchall()]

    def unresolved(self) -> list:
        rows = self.conn.execute(
            "SELECT d.event_id FROM decision_journal d "
            "LEFT JOIN decision_outcomes o ON o.event_id = d.event_id "
            "WHERE o.event_id IS NULL ORDER BY d.ts_ns ASC").fetchall()
        return [self.get_decision(r[0]) for r in rows]

    def close(self) -> None:
        self.conn.close()
