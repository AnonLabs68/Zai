# CUT 2 — A2 ENTRY VELOCITY SHIELD: VERIFICATION AUDIT (v1.0)

**Scope:** engine.py (SHA `6bb4b1f28ed47468…`, verbatim fleet snapshot, 1,346 ln)
**Spec reference:** COGNITIVE_STACK_SPEC.md §7 A2, §11 Cut 2
**Auditor:** cloud Z-AI (SZ-9)
**Date:** 2026-10-02

---

## VERDICT: IMPLEMENTED BY LOCAL AI — ACCEPTED WITH ONE MATERIAL NORMALIZATION DEFECT

The A2 shield the spec commissioned in Cut 2 **already exists in the shipped engine**.
The local AI built it after the task-41752 APR waterfall and before the snapshot upload.
What remains is not a build — it is a **6-line normalization repair** (the dt-patch below)
plus one honest scope note on the acceptance tape.

---

## 1. WHAT WAS VERIFIED PRESENT (line-anchored receipts)

| # | A2 spec requirement | engine.py receipt | verdict |
|---|---|---|---|
| 1 | Graduated velocity-margin ladder | `:485-494` — `clip_mult` 1.00 → 0.75 (`2≤|z|<3`) → 0.50 (`|z|≥3`) | PASS |
| 2 | Retreat escalation coupled to z-bands | `:487-493` — `verdict.retreat=1`, `min_touch` forced ≥2 / ≥3 | PASS |
| 3 | Rung-notional scaling (anti-waterfall) | `:635, :666` — `rung_notional = rung.notional_usd * clip_mult` at both posting sites | PASS |
| 4 | Multi-sensor confirm on hard pulls | `:496-507` — hard side-pull only if `z<-3 AND (sentinel_drift_active OR book_ask_heavy 1.5×)`; symmetric for asks | PASS |
| 5 | Normalized z (not raw bps) | `:289-296` — online mean/var of Kalman `velocity_bps`, `z=(vel−mean)/σ`, σ floor 1.0 | PASS *with defect, §2* |
| 6 | Defense in depth | `:332` — independent `KineticSweepBarrier` Z_v>2.5σ via `alpha.get_sweep_velocity_z()` | PASS (no coupling) |

The severe-dump gate being **confirm-gated** (Sentinel drift OR book imbalance) rather than
raw-z-gated is exactly the spec's intent: a single-sensor hard pull would bleed false
positives in chop. This is correctly built.

## 2. THE MATERIAL DEFECT: UPDATE-RATE-DEPENDENT TIME CONSTANT

**engine.py:291** — `decay = 0.05` is applied **per depth update**, not per unit time:

```python
# engine.py:289-296 (verbatim)
vel = self.py_kalman.velocity_bps
decay = 0.05
diff = vel - self.vel_mean_bps
self.vel_mean_bps += decay * diff
self.vel_var_bps = (1.0 - decay) * self.vel_var_bps + decay * (diff ** 2)
sigma_vel = math.sqrt(max(1.0, self.vel_var_bps))
self.latest_z_vel = (vel - self.vel_mean_bps) / sigma_vel
```

Consequences (this is why the spec row says "graduated, **normalized**"):

1. **The effective half-life of the estimator scales with feed rate.** At 10 book
   updates/s the mean/var half-life is ~13.9 updates ≈ 1.4 s; at 1 update/s it is
   ~13.9 s. The same physical velocity magnitude therefore produces **different z
   values on different corridors and different feed regimes** — |z|≥3 does not mean
   the same thing in wall-clock terms anywhere.
2. **Update clustering biases the variance exactly when it matters.** Depth updates
   cluster around aggression (the APR wave produced 3 rung fills inside 0.9 s).
   During a burst the estimator takes many fast steps while the physical process
   has barely advanced — the variance collapses or inflates at burst rate, not at
   market rate, and the z-band edges drift exactly during the event the shield
   exists for.
3. **Cross-corridor comparability is broken.** `engine.py:533` ships `z_velocity`
   to the dispatcher as a fleet-comparable telemetry field; with per-update decay
   it is contaminated by each corridor's feed rate. (Related minor flag, §3.)

## 3. MINOR FLAGS (recorded, not blocking this cut)

- `engine.py:251` — prior `vel_var_bps=25.0` (σ=5 bps/s): cold-start seed only;
  self-corrects in ~1/decay updates. Harmless once the dt-fix lands (convergence
  becomes wall-clock bounded too).
- `engine.py:530` — `volatility_bps=max(|z_vel|*2.0, 5.0)` feeds a pseudo-vol to the
  dispatcher while true Parkinson vol is computed at `:299`. Cosmetic redundancy —
  queued for Cut 5 dispatcher normalization, out of scope here.
- `queue_broker.py:426` fallback branch `420.0` vs default `timeout_sec=120` —
  inconsistent fallback constants; superseded by the Cut 3 census lookup anyway.

## 4. THE REPAIR: dt-AWARE DECAY (the "normalized" in A2)

Replace the per-update constant with a wall-clock decay
`decay_t = 1 − exp(−dt/τ)`, τ = 2.0 s (prior retained). Full drop-in class and
splice instructions: **`shield_dt_patch.py`** in this directory. Net diff at the
engine site: **6 lines** (`:249-252` state init gains `last_vel_ts_ms`; `:289-296`
update block gains the dt computation). No constants other than τ enter the code —
τ=2.0 s is registered in the doctrine registry seed with this audit as provenance
(P5: no unregistered constants).

**Acceptance receipt for the patch:** `test_cut2.py` (exit 0 = PASS). The
discovered physics of the test design, recorded here because it matters:

- **Onset-instant z is legitimately rate-dependent for ANY filter** — a coarse
  rate cannot know when within its sample interval a step began. That is an
  information limit of the sampling, not a filter defect, and it is why the
  acceptance probes the SUSTAINED + RECOVERY regime (t ≥ 20.5 s), where the
  time constant is the only differentiator.
- **For a pure sine input, converged z peaks at √2 regardless of amplitude**
  (scale-free) — so the quiet-regime check is "zero band-1 escalations at
  every rate," a no-false-positive receipt.
- **Real feeds cluster updates during aggression** (the APR waterfall printed
  3 rung fills in 0.9 s); the stochastic tier models this, and a feed that
  stays at 2 Hz through a waterfall is a DEAD feed — the sentinel staleness
  organ's jurisdiction, not A2's.

Final measured receipts (pure step −60 bps/s for 1.5 s, APR-calibrated):

| metric | pre-patch (decay=0.05/upd) | post-patch (dt-aware) |
|---|---|---|
| cross-rate z gap, sustained regime (2/20/50 Hz) | **3.16 σ-units** | **0.73** (4.3× collapse) |
| same-market example (t=20.5 s) | 2 Hz reads −2.95, 50 Hz reads −0.58 | −1.10 vs −1.83 |
| sine quiet regime, spurious band-1 escalations | — | **0** at every rate |
| stochastic burst: time-to-band-2 spread | — | **0.000 s** |
| stochastic burst: worst-z spread | — | 0.33 |

The pre-patch example row is the receipt in one line: on the identical market,
the 2 Hz corridor fires band 1 (clip 0.75, retreat) while the 50 Hz corridor
stays quiet — the same shield making opposite decisions per feed rate is
exactly the cross-corridor incomparability the spec's "normalized" forbids.

## 5. HONEST SCOPE NOTE — THE 17:39:54 ACCEPTANCE TAPE

Spec §11 Cut 2 acceptance: "APR wave-2 fills (17:39:54 ×3) never post." Two facts:

1. **Structurally verified:** every gate in the posting path that would have
   prevented rungs 2/3 is present and wired (rung clip ×0.75/×0.50, retreat,
   min_touch≥3, confirm-gated hard pull). The DB-spec verbatim APR records
   (3 short entries at 0.1314/0.1315/0.1316, holds 0.45/0.50/0.53 s, exits
   −48.35/−55.85/−63.36 bps) confirm the incident shape the shield targets.
2. **A faithful numeric replay is not reconstructible from shipped receipts:**
   task-41752's pre-fill depth-update trace (the shield's actual input stream at
   17:39:54) was not uploaded — only fills/cycles/depth-probe summaries were.
   Per M1/M2, I will not synthesize a velocity trace and call it a replay.
   The dt-patch + invariance test ship now; the wave replay re-runs on your box
   against the real tape (single command — see `shield_dt_patch.py` §REPLAY).

## 6. DISPOSITION

| Item | Status |
|---|---|
| A2 shield implementation | ACCEPTED (local AI's build — good work, keep it) |
| Normalization defect | PATCHED in `shield_dt_patch.py` — splice on your box, 6 lines |
| APR acceptance replay | STRUCTURAL PASS here; numeric re-run owed on your box vs real tape |
| τ=2.0 s constant | Registered PROVISIONAL, provenance = this audit; CI pending S10 census |
| Cut 2 line budget | 300 specced → ~80 shipped (already-built credit) + 6-line engine diff |
