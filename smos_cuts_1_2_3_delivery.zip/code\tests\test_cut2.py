"""
SMOS V18 — CUT 2 ACCEPTANCE TEST: RATE-INVARIANCE OF THE A2 SHIELD
==================================================================
Run:  python test_cut2.py   (exit 0 = PASS)

Acceptance design (and why — the physics discovered while building it):

TIER 1 (deterministic, pure step input 0 -> -60 bps/s -> 0):
  The DEFECT of the fixed-decay filter (engine.py:291, decay=0.05/update) is a
  rate-dependent TIME CONSTANT: tau_eff = dt/0.05 = 10 s @ 2 Hz vs 0.4 s @
  50 Hz. On a sustained velocity step the 2 Hz corridor's mean/variance adapt
  25x slower than the 50 Hz corridor's, so the same market yields wildly
  different z (and different shield bands) per feed rate. Receipt: cross-rate
  z gap > 1.0 pre-patch; collapsed >= 4x (and < 1.0) post-patch.
  NOTE — onset instant z is legitimately rate-dependent for ANY filter (a
  coarse rate cannot know when within its interval the step began; that is an
  information limit of the sampling, not of the filter). Probes therefore
  cover the SUSTAINED + RECOVERY regime where the time constant is the only
  differentiator. This honesty note is part of the receipt.

TIER 1b (pure sine): for a sinusoid input, converged z peaks at sqrt(2)
  regardless of amplitude (scale-free), so the quiet regime must show ZERO
  band-1 escalations at every rate — no discretization-noise false positives.

TIER 2 (stochastic, common OU path, burst-clustered sampling):
  Real feeds CLUSTER updates during aggression (the APR waterfall printed 3
  rung fills in 0.9 s; a feed that stays at 2 Hz through a waterfall is DEAD —
  the sentinel staleness organ's jurisdiction, not A2's). Metrics are
  distributional: quiet band occupancy, burst band-2 reach, response-time
  spread, burst-peak agreement.

The step is APR-calibrated: rung exits -48/-56/-63 bps inside ~1 s imply
Kalman velocity ~ -60 bps/s for ~1.5 s.
"""

from __future__ import annotations

import math
import random
import sys
from pathlib import Path

_DIR = Path(__file__).resolve().parent
_ROOT = _DIR.parent
for p in [_DIR, _ROOT, _ROOT / "sovereign_fleet" / "governance"]:
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from shield_dt_patch import (LegacyFixedDecayVelocityZ,
                             RateInvariantVelocityZ)

TAU_S = 2.0
HORIZON_S = 40.0
QUIET_RATES_HZ = (2.0, 20.0, 50.0)
BURST_HZ = 50.0

STEP_START_S = 20.0
STEP_LEVEL_BPS_S = -60.0      # APR waterfall: -48..-63 bps in ~1 s
STEP_DURATION_S = 1.5

PRE_PATCH_MIN_GAP_Z = 1.0     # tier-1 defect receipt threshold
GAP_COLLAPSE_RATIO = 4.0      # post-patch gap must shrink >= 4x
POST_PATCH_GAP_MAX_Z = 1.0    # and land under 1.0 sigma-unit

OCCUPANCY_TOL = 0.02          # tier-2 band-occupancy tolerance
T2_TIME_SPREAD_S = 0.2        # tier-2 response-time invariance
BURST_PEAK_SPREAD_Z = 0.5     # tier-2 worst-z agreement

FAILURES: list[str] = []


def check(cond: bool, label: str) -> None:
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}")
    if not cond:
        FAILURES.append(label)


# ---------------------------------------------------------------- inputs --

def step_velocity(t: float) -> float:
    if STEP_START_S <= t < STEP_START_S + STEP_DURATION_S:
        return STEP_LEVEL_BPS_S
    return 0.0


def sine_velocity(t: float) -> float:
    return 6.0 * math.sin(2.0 * math.pi * t / 10.0)


def plain_samples(velocity_fn, rate_hz: float):
    """Sample velocity_fn on an INTEGER-MILLISECOND grid at rate_hz (venue_ms
    is integer in the real engine; float accumulation drifts sample phase at
    event boundaries and coin-flips boundary inclusion)."""
    step_ms = int(round(1000.0 / rate_hz))
    end_ms = int(round(HORIZON_S * 1000))
    ts, vs = [], []
    t_ms = 0
    while t_ms <= end_ms:
        t = t_ms / 1000.0
        ts.append(t)
        vs.append(velocity_fn(t))
        t_ms += step_ms
    return ts, vs


def build_ou_reference(seed: int = 7):
    """Common physical process: OU(1.2, 6.0 bps/s) at 100 Hz with the
    APR-shaped velocity step at t=20."""
    rng = random.Random(seed)
    dt = 1.0 / 100.0
    n = int(HORIZON_S * 100.0)
    kappa, sigma = 1.2, 6.0
    x, ts, vs = 0.0, [], []
    for i in range(n):
        x += (-kappa * x) * dt + sigma * math.sqrt(dt) * rng.gauss(0.0, 1.0)
        t = i * dt
        v = x + (STEP_LEVEL_BPS_S if STEP_START_S <= t <
                 STEP_START_S + STEP_DURATION_S else 0.0)
        ts.append(t)
        vs.append(v)
    return ts, vs


def sample_reference(ref_ts, ref_vs, rate_hz: float, pad_s: float = 0.5):
    """Subsample the reference at rate_hz, EXCEPT the aggression cluster
    window [step_start - pad, step_end + pad] which is sampled at BURST_HZ
    for every variant (update clustering during aggression)."""
    dense_lo_ms = int(round((STEP_START_S - pad_s) * 1000))
    dense_hi_ms = int(round((STEP_START_S + STEP_DURATION_S + pad_s) * 1000))
    step_ms = int(round(1000.0 / rate_hz))
    burst_step_ms = int(round(1000.0 / BURST_HZ))
    out_ts, out_vs = [], []
    t_ms = 0
    end_ms = int(round(HORIZON_S * 1000))
    while t_ms <= end_ms:
        r_ms = burst_step_ms if dense_lo_ms <= t_ms <= dense_hi_ms else step_ms
        t = t_ms / 1000.0
        j = min(range(len(ref_ts)), key=lambda k: abs(ref_ts[k] - t))
        out_ts.append(ref_ts[j])
        out_vs.append(ref_vs[j])
        t_ms += r_ms
    return out_ts, out_vs


# ------------------------------------------------------------- estimation --

def run_estimator(est, ts, vs):
    return [est.update(v, int(round(t * 1000.0))) for t, v in zip(ts, vs)]


def z_at(ts, zs, t_query: float) -> float:
    best_i = min(range(len(ts)), key=lambda i: abs(ts[i] - t_query))
    return zs[best_i]


def cross_rate_gap(det, zs_by_rate, probes) -> tuple[float, float]:
    """Max pairwise |z_a - z_b| at matched probe times. Returns (max_gap,
    worst_t)."""
    max_gap, worst_t = 0.0, 0.0
    for tq in probes:
        vals = [z_at(det[r][0], zs_by_rate[r], tq) for r in QUIET_RATES_HZ]
        gap = max(vals) - min(vals)
        if gap > max_gap:
            max_gap, worst_t = gap, tq
    return max_gap, worst_t


def band_counts(zs, lo_t: float, hi_t: float, ts):
    b = [0, 0, 0]
    n = 0
    for t, z in zip(ts, zs):
        if lo_t <= t <= hi_t:
            az = abs(z)
            b[0 if az < 2.0 else (1 if az < 3.0 else 2)] += 1
            n += 1
    if n == 0:
        return (0.0, 0.0, 0.0)
    return (b[0] / n, b[1] / n, b[2] / n)


def first_time_band2(ts, zs) -> float:
    for t, z in zip(ts, zs):
        if abs(z) >= 3.0:
            return t
    return math.inf


# ------------------------------------------------------------------- main --

def main() -> int:
    print("CUT 2 ACCEPTANCE — A2 velocity shield rate-invariance")
    print(f"  tier-1 input: pure step {STEP_LEVEL_BPS_S:.0f} bps/s for "
          f"{STEP_DURATION_S}s @ t={STEP_START_S:.0f}s (deterministic)")
    print(f"  tier-2 input: OU(1.2, 6.0) common path, burst-cluster @ {BURST_HZ:.0f}Hz")
    print(f"  quiet rates = {QUIET_RATES_HZ} Hz | tau = {TAU_S}s | "
          f"horizon = {HORIZON_S}s\n")

    # ========== TIER 1: deterministic step — the time-constant receipt =====
    step_det = {r: plain_samples(step_velocity, r) for r in QUIET_RATES_HZ}
    # Sustained + recovery regime (excludes the onset instant, whose z is
    # legitimately rate-dependent for any filter — the coarse rate cannot
    # know when within its interval the step began; information limit, not
    # filter defect; documented in the module docstring).
    probes = [round(20.5 + 0.5 * i, 1) for i in range(12)]  # 20.5 .. 26.0

    print("[1] TIER 1 PRE-patch (fixed decay=0.05) — rate-dependent tau_eff")
    pre_z = {r: run_estimator(LegacyFixedDecayVelocityZ(), *step_det[r])
             for r in QUIET_RATES_HZ}
    g_pre, worst_pre = cross_rate_gap(step_det, pre_z, probes)
    for tp in (20.5, 21.0, 21.5, 22.5, 24.0, 26.0):
        vals = {r: z_at(step_det[r][0], pre_z[r], tp) for r in QUIET_RATES_HZ}
        print(f"    t={tp:5.1f}s  z: " +
              "  ".join(f"{r:5.1f}Hz={vals[r]:+6.2f}" for r in QUIET_RATES_HZ))
    print(f"    max cross-rate gap G_pre = {g_pre:.2f} "
          f"(worst t={worst_pre:.1f}s; tau_eff 10s @2Hz vs 0.4s @50Hz)")
    check(g_pre > PRE_PATCH_MIN_GAP_Z,
          f"pre-patch cross-rate z gap {g_pre:.2f} > {PRE_PATCH_MIN_GAP_Z} "
          f"(defect reproduced)")

    print("\n[2] TIER 1 POST-patch (dt-aware, tau=2.0s) — gap collapse")
    post_z = {r: run_estimator(RateInvariantVelocityZ(TAU_S), *step_det[r])
              for r in QUIET_RATES_HZ}
    g_post, worst_post = cross_rate_gap(step_det, post_z, probes)
    for tp in (20.5, 21.0, 21.5, 22.5, 24.0, 26.0):
        vals = {r: z_at(step_det[r][0], post_z[r], tp) for r in QUIET_RATES_HZ}
        print(f"    t={tp:5.1f}s  z: " +
              "  ".join(f"{r:5.1f}Hz={vals[r]:+6.2f}" for r in QUIET_RATES_HZ))
    ratio = g_pre / max(g_post, 1e-9)
    print(f"    max cross-rate gap G_post = {g_post:.2f} "
          f"(worst t={worst_post:.1f}s) | collapse ratio = {ratio:.1f}x")
    check(g_post <= g_pre / GAP_COLLAPSE_RATIO,
          f"gap collapse >= {GAP_COLLAPSE_RATIO:.0f}x: "
          f"{g_pre:.2f} -> {g_post:.2f}")
    check(g_post < POST_PATCH_GAP_MAX_Z,
          f"post-patch gap {g_post:.2f} < {POST_PATCH_GAP_MAX_Z} "
          f"(same continuous filter at every rate, sustained regime)")

    # ========== TIER 1b: pure sine — no spurious quiet escalation ==========
    print("\n[3] TIER 1b POST-patch — pure sine quiet regime "
          "(z peaks at sqrt(2) scale-free: zero band-1 escalations)")
    sine_det = {r: plain_samples(sine_velocity, r) for r in QUIET_RATES_HZ}
    sine_z = {r: run_estimator(RateInvariantVelocityZ(TAU_S), *sine_det[r])
              for r in QUIET_RATES_HZ}
    for r in QUIET_RATES_HZ:
        zs = sine_z[r]
        esc = sum(1 for z in zs if abs(z) >= 2.0)
        peak = max(abs(z) for z in zs)
        print(f"    {r:5.1f}Hz: peak |z| = {peak:.3f} | band-1+ samples = {esc}")
        check(esc == 0,
              f"{r}Hz sine regime: zero spurious band-1 escalations "
              f"(peak |z| {peak:.2f} < 2.0)")

    # ================= TIER 2: stochastic equivalence ======================
    print("\n[4] TIER 2 POST-patch — stochastic band-occupancy equivalence")
    ref_ts, ref_vs = build_ou_reference()
    stoch = {r: sample_reference(ref_ts, ref_vs, r) for r in QUIET_RATES_HZ}
    post2 = {r: run_estimator(RateInvariantVelocityZ(TAU_S), *stoch[r])
             for r in QUIET_RATES_HZ}

    quiet_lo = STEP_START_S + STEP_DURATION_S + 1.5
    quiet_hi = HORIZON_S
    occ = {r: band_counts(post2[r], quiet_lo, quiet_hi, stoch[r][0])
           for r in QUIET_RATES_HZ}
    for r in QUIET_RATES_HZ:
        print(f"    {r:5.1f}Hz quiet occupancy: band0={occ[r][0]:.3f} "
              f"band1={occ[r][1]:.3f} band2={occ[r][2]:.3f}")
    max_occ_gap = max(max(abs(occ[a][k] - occ[b][k]) for k in range(3))
                      for a in QUIET_RATES_HZ for b in QUIET_RATES_HZ)
    check(max_occ_gap < OCCUPANCY_TOL,
          f"quiet band-occupancy agreement {max_occ_gap:.4f} < {OCCUPANCY_TOL}")

    print("\n[5] TIER 2 burst detection + response-time invariance")
    t2s, worsts = {}, {}
    for r in QUIET_RATES_HZ:
        ts, zs = stoch[r][0], post2[r]
        t2s[r] = first_time_band2(ts, zs)
        worsts[r] = min(zs)
        est = RateInvariantVelocityZ(TAU_S)
        est.z = worsts[r]
        print(f"    {r:5.1f}Hz: worst z = {worsts[r]:+6.2f} -> band "
              f"{est.band()} clip {est.clip_mult():.2f} | "
              f"t(band2) = {t2s[r]:.2f}s")
        check(est.band() == 2 and est.clip_mult() == 0.50,
              f"{r}Hz burst reaches |z|>=3, clip 0.50 (rung-scaling armed)")
    t2_list = [t2s[r] for r in QUIET_RATES_HZ]
    spread_t2 = max(t2_list) - min(t2_list)
    spread_wz = max(worsts.values()) - min(worsts.values())
    print(f"    time-to-band2 spread = {spread_t2:.3f}s | worst-z spread = "
          f"{spread_wz:.3f}")
    check(all(math.isfinite(t) for t in t2_list)
          and spread_t2 <= T2_TIME_SPREAD_S,
          f"response-time invariance: spread {spread_t2:.3f}s "
          f"<= {T2_TIME_SPREAD_S}s")
    check(spread_wz <= BURST_PEAK_SPREAD_Z,
          f"burst peak agreement: {spread_wz:.3f} <= {BURST_PEAK_SPREAD_Z}")

    # ================= consumption semantics unchanged =====================
    print("\n[6] severe-pull confirm gate (engine.py:503-507 semantics)")
    est = RateInvariantVelocityZ(TAU_S)
    est.z = -3.5
    check(est.severe_pull(False, False) is False,
          "z=-3.5 with no confirming sensor -> NO pull (multi-sensor confirm)")
    check(est.severe_pull(True, False) is True, "z=-3.5 + sentinel drift -> pull")
    check(est.severe_pull(False, True) is True, "z=-3.5 + book imbalance -> pull")
    est.z = -2.9
    check(est.severe_pull(True, True) is False,
          "z=-2.9 + both sensors -> NO pull (band 1, soft clip only)")

    print("\n[7] burst duplicate-timestamp safety")
    est = RateInvariantVelocityZ(TAU_S)
    est.update(5.0, 10_000)
    z1 = est.update(80.0, 10_000)   # same ms — must not double-step
    z2 = est.update(80.0, 10_000)
    check(z1 == z2 and est.mean_bps < 80.0,
          "same-timestamp updates decay=0 (no variance collapse in bursts)")

    print("\n[8] registry constant")
    check(TAU_S == 2.0, "vel_shield_tau_s = 2.0 registered PROVISIONAL "
          "(provenance: cut2/AUDIT.md §4; CI pending S10 census)")

    print()
    if FAILURES:
        print(f"CUT 2: {len(FAILURES)} FAILURE(S):")
        for f in FAILURES:
            print(f"  - {f}")
        return 1
    print("CUT 2: ALL CHECKS PASS — A2 shield accepted; dt-patch certified "
          "(time-constant gap collapse + no spurious escalation + stochastic "
          "equivalence + response-time invariance)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
