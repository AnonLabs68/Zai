"""
SMOS V18 — CUT 3 ACCEPTANCE TEST
================================
Run:  python test_cut3.py   (exit 0 = PASS)

Acceptance map (spec §11 Cut 3: "14-day bounce-onset percentiles replace
flat 300s" — with the honest n<30 reality of the shipped corpus):

 [1] Markout math + bounce detection (MID_PATH mode, hand-computable)
 [2] EXIT_BOUNDED mode: favorable exit -> onset <= hold; adverse -> censored
 [3] Kaplan-Meier estimator certification on KNOWN-TRUTH synthetic survival
     data (exponential ground truth, with and without censoring). This
     certifies the ESTIMATOR, installs no thresholds (P5/M1).
 [4] Greenwood variance + KM hand case
 [5] Persistence: fill_census + markout_snapshots rows written (fixes the
     =0 organ), WAL mode, append-only
 [6] THE HONEST ACCEPTANCE: bootstrap corpus -> every coin n < 30 ->
     ALL PROVISIONAL -> t1_cadence_s returns the incumbent flat timeout for
     every corridor (retirement correctly DEFERRED, zero behavior change)
 [7] Retirement fires only under TEST-ONLY inflation (n=35 synthetic GRAM
     events -> CENSUSED -> cadence = clamp(1.25 * P50, 30, 900))
 [8] R6 edge ledger on the verbatim corpus: all verdicts UNPROVEN (n < 20),
     APR correctly the worst coin, cohort arithmetic cross-checked vs
     task-41752 receipts
 [9] Wilson interval closed-form verification
[10] R6 verdict gates under test-only inflation: GRAM -> PROVEN, APR -> FALSIFIED
[11] SNIPE re-trial gate: n_taker = 0 -> ineligible (SZ-8 kill receipt intact)
[12] Registry amendments carry provenance + CI + cadence fields
"""

from __future__ import annotations

import math
import os
import random
import sqlite3
import tempfile
import sys
from pathlib import Path

_DIR = Path(__file__).resolve().parent
_ROOT = _DIR.parent
for p in [_DIR, _ROOT, _ROOT / "sovereign_fleet" / "governance"]:
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from s10_fill_tape_recorder import (FillObservation, KaplanMeier,
                                    S10FillTapeRecorder, CENSUS_MIN_N,
                                    T1_P50_MULTIPLIER, HORIZONS_S)
from r6_edge_accountant import (R6EdgeAccountant, CycleRecord,
                                wilson_interval)
import fixtures_cut3 as fx

FAILURES: list[str] = []


def check(cond: bool, label: str) -> None:
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}")
    if not cond:
        FAILURES.append(label)


def main() -> int:
    print("CUT 3 ACCEPTANCE — S10 fill-tape recorder + R6 edge accountant\n")

    # ------------------------------------------------------------- [1] ----
    print("[1] markout math + bounce detection (MID_PATH, hand-computable)")
    ts0 = 1_000_000_000_000_000_000
    obs = FillObservation(
        fill_id="X1", corridor="XUSDT", ts_ns=ts0, side="BUY",
        entry_px=100.0, qty=1.0, spread_bps_at_fill=10.0)  # target = +5 bps
    mids = [(ts0, 100.0),
            (ts0 + 1_000_000_000, 100.02),     # +2.0 bps @ 1s
            (ts0 + 5_000_000_000, 100.06),     # +6.0 bps @ 5s -> BOUNCE
            (ts0 + 30_000_000_000, 100.03),    # +3.0 bps @ 30s
            (ts0 + 60_000_000_000, 99.99),     # -1.0 bps @ 60s
            ]
    rec = S10FillTapeRecorder()
    rec.register_fill(obs)
    for (t, m) in mids:
        rec.on_mid("XUSDT", t, m)
    rec.settle("X1", exit_px=100.03, exit_ns=ts0 + 30_000_000_000,
               exit_tier="TEST", net_pnl_bps=3.0)
    row = rec.evaluated_rows()[0]
    check(abs(row["markout_1s_bps"] - 2.0) < 1e-9,
          "markout_1s = +2.0 bps (hand value)")
    check(abs(row["markout_5s_bps"] - 6.0) < 1e-9,
          "markout_5s = +6.0 bps (hand value)")
    check(abs(row["markout_60s_bps"] - (-1.0)) < 1e-9,
          "markout_60s = -1.0 bps (hand value)")
    check(row["bounce_onset_s"] == 5.0,
          "bounce onset = 5.0 s (first mid >= +5 bps target)")
    check(row["censored"] == 0 and row["evidence_mode"] == "MID_PATH",
          "MID_PATH mode, uncensored")
    check(abs(row["adverse_excursion_bps"] - (-1.0)) < 1e-9,
          "adverse excursion = -1.0 bps (worst over window)")

    # ------------------------------------------------------------- [2] ----
    print("\n[2] EXIT_BOUNDED mode (historical bootstrap evidence)")
    obs2 = FillObservation(
        fill_id="X2", corridor="YUSDT", ts_ns=ts0, side="SELL",
        entry_px=50.0, qty=2.0, spread_bps_at_fill=None)  # target 4.0 default
    rec2 = S10FillTapeRecorder()
    rec2.register_fill(obs2)
    rec2.settle("X2", exit_px=49.98, exit_ns=ts0 + 3_000_000_000,
                exit_tier="PASSIVE_MAKER_HARVEST", net_pnl_bps=+9.0)
    row2 = rec2.evaluated_rows()[0]
    check(row2["bounce_onset_s"] == 3.0 and row2["censored"] == 0,
          "favorable exit (+9 bps >= 4 target): onset <= hold 3.0 s, event")
    obs3 = FillObservation(
        fill_id="X3", corridor="YUSDT", ts_ns=ts0, side="SELL",
        entry_px=50.0, qty=2.0, spread_bps_at_fill=None)
    rec2.register_fill(obs3)
    rec2.settle("X3", exit_px=50.05, exit_ns=ts0 + 1_000_000_000,
                exit_tier="KINEMATIC_EJECT", net_pnl_bps=-31.0)
    row3 = [r for r in rec2.evaluated_rows() if r["fill_id"] == "X3"][0]
    check(row3["bounce_onset_s"] is None and row3["censored"] == 1,
          "adverse exit (-31 bps): censored at hold 1.0 s, no bounce claimed")
    check(row3["adverse_excursion_bps"] == -31.0,
          "adverse excursion from settle pnl = -31.0 bps")

    # ------------------------------------------------------------- [3] ----
    print("\n[3] Kaplan-Meier estimator certification (known truth)")
    rng = random.Random(2026)
    lam = 1.0 / 10.0                       # ground truth: Exp(mean 10 s)
    truth_p50 = math.log(2.0) / lam        # 6.931 s
    n = 400
    evts, cens = [], []
    for _ in range(n):
        t = rng.expovariate(lam)
        cen = rng.expovariate(0.05)        # light censoring (5% rate)
        if cen < t:
            cens.append(cen)
        else:
            evts.append(t)
    km = KaplanMeier(evts, cens)
    p50, ci_lo, ci_hi = km.median()
    print(f"    truth P50 = {truth_p50:.3f}s | KM P50 = {p50:.3f}s | "
          f"CI = [{ci_lo}, {ci_hi}] | n = {n} "
          f"({len(evts)} events / {len(cens)} censored)")
    check(p50 is not None and abs(p50 - truth_p50) < 0.5,
          "KM P50 within 0.5 s of exponential truth (ln2/lambda = 6.93)")
    check(ci_lo is not None and ci_lo <= p50 <= ci_hi,
          "P50 inside its own CI (lo <= p50 <= hi)")
    # no-censoring control: FRESH uncensored draws (reusing the truncated
    # events subset would be selection-biased — see the receipt below)
    ctrl_evts = [rng.expovariate(lam) for _ in range(n)]
    km_nc = KaplanMeier(ctrl_evts, [])
    p50b, _, _ = km_nc.median()
    print(f"    no-censoring KM P50 = {p50b:.3f}s (truth 6.93, "
          f"sampling se of median ~ 0.5 s at n=400)")
    check(abs(p50b - truth_p50) < 1.0,
          "no-censoring KM P50 within 1.0 s (~2 sigma of the median's "
          "sampling error)")
    # SELECTION-BIAS RECEIPT: the naive drop-the-censored analysis
    naive_km = KaplanMeier(evts, [])     # WRONG analysis of censored data
    naive_p50 = naive_km.median()[0]
    print(f"    naive drop-the-censored median = {naive_p50:.3f}s vs proper "
          f"KM = {p50:.3f}s — a {100*(1-naive_p50/p50):.0f}% downward bias")
    check(naive_p50 < 0.85 * p50,
          "receipt: naive drop-the-censored median biased LOW "
          f"({naive_p50:.2f} vs {p50:.2f}) — the exact failure mode "
          "censoring-aware estimation exists to prevent (adverse exits "
          "are censored observations, not absent ones)")
    # heavy censoring (50%)
    evts2, cens2 = [], []
    for _ in range(n):
        t = rng.expovariate(lam)
        cen = rng.expovariate(lam)         # equal-rate censoring
        if cen < t:
            cens2.append(cen)
        else:
            evts2.append(t)
    km2 = KaplanMeier(evts2, cens2)
    p50c, _, _ = km2.median()
    print(f"    50% censoring: KM P50 = {p50c:.3f}s (truth 6.93)")
    check(p50c is not None and abs(p50c - truth_p50) < 0.8,
          "50%-censored KM P50 within 0.8 s (the adverse-exit regime)")

    # ------------------------------------------------------------- [4] ----
    print("\n[4] KM hand case + Greenwood variance")
    kmh = KaplanMeier([1.0, 2.0, 3.0, 4.0], [])
    check(abs(kmh.survival(1.0) - 0.75) < 1e-12, "S(1) = 0.75 (hand)")
    check(abs(kmh.survival(2.0) - 0.50) < 1e-12, "S(2) = 0.50 (hand)")
    p, lo, hi = kmh.median()
    check(p == 2.0, "median = 2.0 (hand)")
    gv = kmh._greenwood_var(2.0)
    check(abs(gv - 0.0625) < 1e-12,
          "Greenwood Var S(2) = 0.0625 (hand: 0.25*(1/12+1/6))")
    kmh2 = KaplanMeier([1.0, 3.0], [2.0, 4.0])
    check(abs(kmh2.survival(3.0) - 0.375) < 1e-12,
          "censored hand case: S(3) = 0.375 = 0.75 * (1 - 1/2)")

    # ------------------------------------------------------------- [5] ----
    print("\n[5] persistence: fill_census + markout_snapshots (fixing =0)")
    db = os.path.join(tempfile.mkdtemp(), "cut3_test.db")
    rec3 = S10FillTapeRecorder()
    for o in fx.s10_bootstrap_observations():
        rec3.register_fill(o)
    for o in fx.s10_bootstrap_observations():
        rec3.settle(o.fill_id, exit_px=(o.exit_px or o.entry_px),
                    exit_ns=o.exit_ns, exit_tier=o.exit_tier or "UNKNOWN",
                    net_pnl_bps=o.net_pnl_bps)
    n_rows = rec3.flush(db)
    check(n_rows == 6, f"6 fill_census rows written (got {n_rows})")
    conn = sqlite3.connect(db)
    fc = conn.execute("SELECT COUNT(*), SUM(censored) FROM fill_census")\
        .fetchone()
    ms = conn.execute("SELECT COUNT(*) FROM markout_snapshots").fetchone()[0]
    wal = conn.execute("PRAGMA journal_mode").fetchone()[0]
    conn.close()
    check(fc[0] == 6, f"fill_census persisted rows = {fc[0]}")
    check(fc[1] == 4, "4 censored (APR x3 + AZTEC), 2 events (OPG, ESPORTS)")
    check(ms == 6 * len(HORIZONS_S),
          f"markout_snapshots rows = {ms} (6 fills x {len(HORIZONS_S)} "
          f"horizons — the =0 table now writes)")
    check(wal.lower() == "wal", f"journal_mode = {wal} (fleet DB spec)")
    # append-only: re-flush must not duplicate
    n2 = rec3.flush(db)
    conn = sqlite3.connect(db)
    fc2 = conn.execute("SELECT COUNT(*) FROM fill_census").fetchone()[0]
    ms2 = conn.execute("SELECT COUNT(*) FROM markout_snapshots").fetchone()[0]
    conn.close()
    check(fc2 == 6 and ms2 == 6 * len(HORIZONS_S),
          "append-only: re-flush of same observations writes nothing new (B5)")

    # ------------------------------------------------------------- [6] ----
    print("\n[6] THE HONEST ACCEPTANCE — bootstrap census, retirement DEFERRED")
    census = rec3.build_census(provenance="cut3 fixtures: task-41752 + "
                                          "DB-spec verbatim + SZ-6 receipts")
    all_ok = True
    for corridor, cc in sorted(census.coins.items()):
        fallback_used = census.t1_cadence_s(corridor, fallback=120.0)
        print(f"    {corridor:12s} n={cc.n:2d} events={cc.n_events} "
              f"censored={cc.n_censored} status={cc.status:12s} "
              f"t1_cadence={fallback_used:.1f}s (fallback 120)")
        if cc.status == "CENSUSED" or fallback_used != 120.0:
            all_ok = False
    check(all_ok,
          "every coin n < 30 -> PROVISIONAL/NO_BOUNCE -> flat timeout kept "
          "(zero behavior change until the census earns it — P5)")
    check(census.t1_cadence_s("APRUSDT", 120.0) == 120.0,
          "APR (3 adverse censored, zero bounces) keeps incumbent timeout")

    # ------------------------------------------------------------- [7] ----
    print("\n[7] retirement fires only under TEST-ONLY inflation")
    rng2 = random.Random(99)
    rec4 = S10FillTapeRecorder()
    for i in range(35):
        hold = rng2.uniform(1.0, 9.0)     # synthetic GRAM-like fast bounces
        ts = 1_000_000_000_000_000_000 + i * 10_000_000_000
        o = FillObservation(
            fill_id=f"SYNTH_G{i}", corridor="GRAMUSDT", ts_ns=ts,
            side="SELL", entry_px=1.5, qty=4.0, spread_bps_at_fill=None)
        rec4.register_fill(o)
        rec4.settle(f"SYNTH_G{i}", exit_px=1.4995, exit_ns=ts + int(hold * 1e9),
                    exit_tier="SYNTH", net_pnl_bps=+7.0)  # events at hold
    cen4 = rec4.build_census(provenance="TEST-ONLY synthetic inflation")
    cc4 = cen4.coins["GRAMUSDT"]
    expected = min(900.0, max(30.0, T1_P50_MULTIPLIER * cc4.p50_s))
    print(f"    GRAMUSDT n={cc4.n} p50={cc4.p50_s:.3f}s ci={cc4.ci} "
          f"status={cc4.status} cadence={cen4.t1_cadence_s('GRAMUSDT', 120.0):.1f}s")
    check(cc4.status == "CENSUSED",
          f"n={cc4.n} >= {CENSUS_MIN_N} with tight CI -> CENSUSED")
    check(abs(cen4.t1_cadence_s("GRAMUSDT", 120.0) - expected) < 1e-9,
          f"cadence = clamp(1.25 x P50, 30, 900) = {expected:.1f}s "
          f"(!= fallback 120 — retirement mechanism proven)")
    check(cen4.t1_cadence_s("MITOUSDT", 120.0) == 120.0,
          "un-inflated coin still keeps fallback (gate is per-coin)")

    # ------------------------------------------------------------- [8] ----
    print("\n[8] R6 edge ledger on the verbatim corpus")
    r6 = R6EdgeAccountant()
    r6.add_cycles(fx.r6_bootstrap_cycles())
    ledger = {e.corridor: e for e in r6.coin_ledger()}
    for e in r6.coin_ledger():
        print(f"    {e.corridor:12s} n={e.n:2d} WR={e.win_rate:.2f} "
              f"wilsonLB={e.wilson_lb_win:.3f} mean={e.mean_bps:+7.2f}bps "
              f"boot=[{e.boot_lb_bps},{e.boot_ub_bps}] {e.verdict}")
    check(all(e.verdict == "UNPROVEN" for e in ledger.values()),
          "all coins UNPROVEN at bootstrap n (max 12 < 20 gate) — honest")
    check(ledger["APRUSDT"].mean_bps < -30.0,
          "APR mean bps deeply negative (-51.1) — receipt-consistent "
          "(waterfall cohort)")
    # cohort arithmetic cross-check vs task-41752 receipts (that run ONLY —
    # DB-spec cycles are a different run and must not pollute the check)
    t41752_fort_usd = sum(usd for (sym, usd, _t, _n) in fx._T41752
                          if sym in fx.FORTRESS_COHORT)
    t41752_thin_usd = sum(usd for (sym, usd, _t, _n) in fx._T41752
                          if sym in fx.THIN_COHORT)
    check(abs(t41752_fort_usd - 0.0842) < 5e-4,
          f"fortress cohort net = ${t41752_fort_usd:.4f} (receipt +0.0842)")
    check(abs(t41752_thin_usd - (-0.2941)) < 5e-4,
          f"thin cohort net = ${t41752_thin_usd:.4f} (receipt -0.2941)")
    # worst coin by total damage (n-weighted), the receipt-consistent metric
    totals = {}
    for c in r6.cycles:
        totals[c.corridor] = totals.get(c.corridor, 0.0) + (c.net_usd or 0.0)
    worst_coin = min(totals, key=lambda k: totals[k])
    check(worst_coin == "APRUSDT",
          f"APR is the worst coin by total damage (${totals[worst_coin]:.4f}) "
          f"— receipt-consistent (largest single-corridor bleed)")
    sb = r6.fortress_scoreboard(fx.FORTRESS_COHORT)
    print(f"    fortress scoreboard: n={sb['n']} WR={sb['win_rate']} "
          f"mean={sb['mean_bps']}bps boot_lb={sb['boot_lb_bps']}bps "
          f"(target wilson_lb >= +3bps: meets={sb['meets_bps_target']})")
    check(sb["n"] == 13, "fortress scoreboard n = 13 (receipt)")
    check(sb["meets_bps_target"] ==
          (sb["boot_lb_bps"] is not None
           and sb["boot_lb_bps"] >= sb["target_wilson_lb_bps"]),
          "scoreboard flag consistent with its own bootstrap LB vs target "
          f"(early receipt: LB = {sb['boot_lb_bps']} bps at n=13 — reported "
          "as-is, n still below every verdict gate)")

    # ------------------------------------------------------------- [9] ----
    print("\n[9] Wilson interval closed-form verification")
    # k=3, n=12: p=0.25, z^2=3.84146, denom=1.32012; center=0.41006/denom
    # = 0.31062; half-width = 1.96*sqrt(0.015625+0.0066693)/denom = 0.22168
    lo, hi = wilson_interval(3, 12)
    check(abs(lo - 0.0889) < 5e-4, f"wilson(3,12) LB = {lo:.4f} (hand 0.0889)")
    check(abs(hi - 0.5323) < 5e-4, f"wilson(3,12) UB = {hi:.4f} (hand 0.5323)")
    # k=13, n=13: center=(1+3.84146/26)/1.29550=0.88594;
    # half=1.96*sqrt(3.84146/676)/1.29550=0.11407 -> LB=0.77186
    lo2, hi2 = wilson_interval(13, 13)
    check(hi2 == 1.0, "wilson(13,13) UB = 1.0")
    check(abs(lo2 - 0.7719) < 5e-4,
          f"wilson(13,13) LB = {lo2:.4f} (hand 0.7719 — small-sample "
          f"humility: 13/13 wins is not 100%)")
    lo3, _ = wilson_interval(0, 12)
    check(lo3 < 0.001, "wilson(0,12) LB ~ 0 (no wins)")

    # ------------------------------------------------------------ [10] ----
    print("\n[10] R6 verdict gates under TEST-ONLY inflation")
    rng3 = random.Random(7)
    # GRAM-like: +12 bps mean, sd 8 -> PROVEN at n=25
    recs_p = [CycleRecord(corridor="GRAMUSDT",
                          pnl_bps=round(rng3.gauss(12.0, 8.0), 2),
                          exit_tier="PASSIVE_MAKER_HARVEST")
              for _ in range(25)]
    r6p = R6EdgeAccountant()
    r6p.add_cycles(recs_p)
    v_p = {e.corridor: e for e in r6p.coin_ledger()}["GRAMUSDT"].verdict
    check(v_p == "PROVEN", f"strong positive coin -> PROVEN (got {v_p})")
    # APR-like: -25 bps mean, sd 15 -> FALSIFIED at n=25
    recs_f = [CycleRecord(corridor="APRUSDT",
                          pnl_bps=round(rng3.gauss(-25.0, 15.0), 2),
                          exit_tier="WATERFALL")
              for _ in range(25)]
    r6f = R6EdgeAccountant()
    r6f.add_cycles(recs_f)
    v_f = {e.corridor: e for e in r6f.coin_ledger()}["APRUSDT"].verdict
    check(v_f == "FALSIFIED", f"strong negative coin -> FALSIFIED "
                              f"(G5 demotion evidence; got {v_f})")
    # borderline at n=25 must NOT fire either direction
    recs_b = [CycleRecord(corridor="MITOUSDT",
                          pnl_bps=round(rng3.gauss(0.0, 20.0), 2),
                          exit_tier="MIXED") for _ in range(25)]
    r6b = R6EdgeAccountant()
    r6b.add_cycles(recs_b)
    v_b = {e.corridor: e for e in r6b.coin_ledger()}["MITOUSDT"].verdict
    check(v_b == "UNPROVEN", f"zero-edge coin -> UNPROVEN (got {v_b})")
    # n below gate: even perfect performance stays UNPROVEN
    recs_n = [CycleRecord(corridor="OPGUSDT", pnl_bps=15.0,
                          exit_tier="HARVEST") for _ in range(10)]
    r6n = R6EdgeAccountant()
    r6n.add_cycles(recs_n)
    v_n = {e.corridor: e for e in r6n.coin_ledger()}["OPGUSDT"].verdict
    check(v_n == "UNPROVEN", "n=10 < 20: UNPROVEN regardless of performance")

    # ------------------------------------------------------------ [11] ----
    print("\n[11] SNIPE re-trial gate (SZ-8 kill receipt intact)")
    st = r6.snipe_retrial_status()
    print(f"    {st}")
    check(st["n_taker"] == 0 and st["eligible"] is False,
          "taker n = 0 -> re-trial INELIGIBLE (gate stays OFF)")
    # synthetic: even 60 profitable snipes below the n=100 line stay OFF
    r6s = R6EdgeAccountant()
    r6s.add_cycles([CycleRecord(corridor="BTCUSDT", pnl_bps=30.0,
                                exit_tier="SNIPE_BUY", is_taker=True)
                    for _ in range(60)])
    st2 = r6s.snipe_retrial_status()
    check(st2["eligible"] is False and st2["n_taker"] == 60,
          "n=60 < 100 with perfect drift: still INELIGIBLE "
          "(pre-registered lines hold)")
    r6s2 = R6EdgeAccountant()
    r6s2.add_cycles([CycleRecord(corridor="BTCUSDT", pnl_bps=30.0,
                                 exit_tier="SNIPE_BUY", is_taker=True)
                     for _ in range(100)])
    st3 = r6s2.snipe_retrial_status()
    check(st3["eligible"] is True,
          "n=100, drift +30bps, hit 100% -> eligible (re-litigation path "
          "exists, only via the pre-registered lines)")

    # ------------------------------------------------------------ [12] ----
    print("\n[12] registry amendments carry provenance + CI + cadence")
    amd = census.to_registry_amendment()
    check(amd["amendment_type"] == "s10_bounce_census"
          and amd["provenance"].startswith("cut3 fixtures"),
          "S10 amendment header correct")
    row_apr = [r for r in amd["rows"]
               if r["name"] == "t1_walk_cadence_s.APRUSDT"][0]
    check(row_apr["state"] in ("PROVISIONAL", "NO_BOUNCE")
          and row_apr["n"] == 3 and row_apr["n_censored"] == 3,
          "APR row: 3 fills, 3 censored, no bounce claimed, not CENSUSED")
    amd2 = r6.to_registry_amendment()
    check(amd2["amendment_type"] == "r6_edge_ledger"
          and len(amd2["coins"]) == 8 and "snipe_retrial" in amd2,
          "R6 amendment: 8 coins + tiers + maker/taker + snipe gate")

    print()
    if FAILURES:
        print(f"CUT 3: {len(FAILURES)} FAILURE(S):")
        for f in FAILURES:
            print(f"  - {f}")
        return 1
    print("CUT 3: ALL CHECKS PASS — S10 recorder + R6 accountant shipped; "
          "census machinery certified on known truth; retirement armed and "
          "correctly deferred at bootstrap n; flat 300s retires the day a "
          "coin earns CENSUSED status")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
