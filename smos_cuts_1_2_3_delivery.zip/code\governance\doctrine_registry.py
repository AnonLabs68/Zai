"""
SMOS V18 — CUT 1 / L3 DOCTRINE REGISTRY (v0)
=============================================
The law layer: single versioned store for every fleet constant.

CONSTITUTION (COGNITIVE_STACK_SPEC.md v1.1, P5):
  - No threshold enters this registry without provenance + cadence + owner.
  - Values are versioned and append-only: installing a new value NEVER mutates
    an old row. Amendments carry a reference (receipt / case id).
  - Incident-shaped constants may be installed ONLY with provenance tagged
    PROVISIONAL and a census pending note (upgrade path = M3 calibration).
  - Any organ reading a hard-coded constant instead of this registry is a
    P5 violation and must appear in audit_inline().

Integration target (their tree):
  sovereign_fleet/governance/doctrine_registry.py   (this file, verbatim)
  Seeded at run_sovereign_fleet() startup; organs replace inline literals
  with DoctrineRegistry.get(<name>).

Stdlib only. SQLite append-only. Zero fleet dependencies.
"""

from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass
from typing import Dict, List, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS doctrine_constants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    version INTEGER NOT NULL,
    value REAL NOT NULL,
    unit TEXT NOT NULL,
    provenance TEXT NOT NULL,
    ci_lo REAL,
    ci_hi REAL,
    installed_ns INTEGER NOT NULL,
    cadence TEXT NOT NULL,
    owner TEXT NOT NULL,
    amendment_ref TEXT
);
CREATE INDEX IF NOT EXISTS ix_dc_name ON doctrine_constants(name, version);
CREATE TABLE IF NOT EXISTS registry_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts_ns INTEGER NOT NULL,
    event TEXT NOT NULL,
    detail TEXT NOT NULL
);
"""


@dataclass
class DoctrineConstant:
    name: str
    version: int
    value: float
    unit: str
    provenance: str
    ci_lo: Optional[float]
    ci_hi: Optional[float]
    installed_ns: int
    cadence: str
    owner: str
    amendment_ref: Optional[str]


# ---------------------------------------------------------------------------
# SEED CORPUS — every entry carries its receipt.
# RECEIPT keys: WP-A (fortress lifecycle law), RESEARCH-1 (527-perp census),
# SZ-3 (rotation doctrine), SZ-4 (lag census), SZ-5 (friction invariant),
# V14 (adversarial stack), V16 (friction wall), V17 (sentinel 88/88),
# task-41752 (28-min 20-corridor live telemetry), INLINE-P5 (constant found
# hard-coded in fleet source during SZ-8 code read — migration required).
# ---------------------------------------------------------------------------

SEED = [
    # name, value, unit, provenance, ci_lo, ci_hi, cadence, owner, ref
    ("taker_friction_wall_bps", 16.2, "bps",
     "V16 measured; SZ-4 independently confirmed", 14.0, 20.0,
     "quarterly", "research", None),
    ("maker_rt_fee_bps", 3.6, "bps",
     "Binance USDT-M VIP-0 schedule (1.8 x 2)", 3.6, 3.6,
     "on-fee-schedule-change", "ops", None),
    ("taker_fee_bps", 4.5, "bps",
     "INLINE-P5: queue_broker.py taker_fee_bps (BNB-discount tier 4.5; "
     "standard VIP-0 is 5.0 — fee fingerprint census pending)", 4.5, 5.0,
     "on-fee-schedule-change", "ops", "SZ-8-code-read"),
    ("doctrine_capture_spec_bps", 12.4, "bps",
     "spread 16 - maker RT 3.6 (doctrine spec band)", 10.0, 16.0,
     "monthly-vs-S5", "research", None),
    ("tau_rel_class2_lo_bps", 4.0, "bps",
     "RESEARCH-1 census (527 perps; only 6 assets > 10 bps)", None, None,
     "monthly", "research", None),
    ("tau_rel_class2_hi_bps", 10.5, "bps",
     "RESEARCH-1 census", None, None,
     "monthly", "research", None),
    ("wpa_fortress_zone_lo", 870.0, "pt_ratio",
     "WP-A pre-registration", None, None,
     "90-day-falsification", "research", None),
    ("wpa_fortress_zone_hi", 1250.0, "pt_ratio",
     "WP-A pre-registration", None, None,
     "90-day-falsification", "research", None),
    ("wpa_age_budget_windows", 270.0, "8h_windows",
     "WP-A KM half-life estimate", 220.0, 330.0,
     "90-day-falsification", "research", None),
    ("volume_floor_usd", 2_000_000.0, "usd_per_day",
     "SZ-3 pre-registered (EWMA 14d half-life)", None, None,
     "90-day", "research", None),
    ("volume_floor_ewma_halflife_d", 14.0, "days",
     "SZ-3 pre-registered", None, None,
     "90-day", "research", None),
    ("r_isolation_max", 0.15, "pearson_r_vs_btc",
     "SZ-4 census (roster r = 0.05-0.10)", 0.10, 0.20,
     "quarterly", "research", None),
    ("theta_l1_cushion_usd", 1000.0, "usd",
     "PROVISIONAL task-41752 6-corridor sample; bootstrap census pending "
     "(Cut 3). Rationale: fortress cohort L1 {4616, 2683, 2556} vs thin "
     "{271, 153, 408} — provisional split pending n>=20 corridors",
     600.0, 1500.0, "monthly-bootstrap", "research", "task-41752"),
    ("theta_l3_cushion_usd", 2500.0, "usd",
     "PROVISIONAL task-41752 6-corridor sample (L3-only pass allowed only "
     "with RESILIENT classification); census pending (Cut 3)",
     2000.0, 4000.0, "monthly-bootstrap", "research", "task-41752"),
    ("z_velocity_confirm", 2.5, "sigma",
     "V14 KineticSweepBarrier (Z_v > 2.5)", None, None,
     "post-cut4", "research", None),
    ("z_velocity_half_band_lo", 2.0, "sigma",
     "INLINE-P5: engine.py graduated shield band 2.0-3.0 (clip_mult 0.75)",
     None, None, "post-census", "research", "SZ-8-code-read"),
    ("z_velocity_hard_band", 3.0, "sigma",
     "INLINE-P5: engine.py hard band (clip_mult 0.50, multi-sensor pull)",
     None, None, "post-census", "research", "SZ-8-code-read"),
    ("cusum_k", 0.5, "sigma",
     "V17 DriftWatch pre-registration", None, None,
     "90-day", "research", None),
    ("cusum_h", 10.0, "cusum_units",
     "V17 DriftWatch pre-registration", None, None,
     "90-day", "research", None),
    ("jump_ladder_sigma", 4.0, "sigma",
     "V17 EdgeRadar (4-sigma, 2-strike debounce)", None, None,
     "90-day", "research", None),
    ("exit_t3_hard_bound_bps", -60.0, "bps",
     "SZ-5 ladder spec default; per-coin tail calibration pending (S10)",
     -80.0, -50.0, "14-day-refresh", "research", None),
    ("quarantine_consecutive_fails", 2.0, "count",
     "INLINE-P5: engine.py ForensicMarkoutDoctor max_consecutive_fails — "
     "task-41752 incident-shaped; census pending", 2.0, 3.0,
     "monthly", "governance", "SZ-8-code-read"),
    ("quarantine_corridor_drawdown_usd", 0.025, "usd",
     "INLINE-P5: engine.py ForensicMarkoutDoctor drawdown line — "
     "incident-shaped; census pending", 0.02, 0.05,
     "monthly", "governance", "SZ-8-code-read"),
    ("quarantine_duration_sec", 1800.0, "seconds",
     "INLINE-P5: engine.py quarantine_duration_sec (30 min)", 900.0, 7200.0,
     "monthly", "governance", "SZ-8-code-read"),
    ("lead_lag_snipe_mode", 0.0, "enum_off_shadow_live",
     "SZ-4 verdict: taker lag-capture DEAD by 8x margin (drift peak "
     "+3.1bps @60s vs +25 kill line, hit 44% vs 60%; 12-sigma BTC shocks "
     "invert to -9.0bps @5min). 0=OFF pending pre-registered shadow re-trial",
     None, None, "on-amendment-only", "governance", "SZ-4-kill"),
    ("lead_lag_jump_threshold_bps", 5.0, "bps",
     "INLINE-P5: engine.py CrossAssetLeadLagEngine jump_threshold_bps — "
     "governs SNIPE path only; PULL path (execution shield) is sanctioned "
     "by V16 slingshot gate doctrine", None, None,
     "on-amendment-only", "governance", "SZ-8-code-read"),
    ("screener_min_volume_usd", 10_000_000.0, "usd_24h",
     "INLINE-P5: engine.py UniverseScreenerDaemon min_volume_usd — deviates "
     "from pre-registered $2M EWMA floor (stricter but spot-24h, no EWMA); "
     "unify at census", None, None,
     "monthly", "research", "SZ-8-code-read"),
    ("screener_min_l1_depth_usd", 1500.0, "usd",
     "INLINE-P5: engine.py UniverseScreenerDaemon min_l1_depth_usd — "
     "REFUTED as a flat admission line by task-41752 MITO counterexample "
     "($271 L1 net-positive vs AT $2,556 L1 net-negative); advisory "
     "candidate-filter only, never an admission gate", None, None,
     "monthly", "research", "SZ-6-adjudication"),
    ("fleet_max_slots", 3.0, "slots",
     "doctrine (25-pool / 15-active / 5-clip)", None, None,
     "quarterly", "governance", None),
    ("fleet_slot_notional_usd", 5.0, "usd",
     "doctrine ($5 min-order wall accommodation)", None, None,
     "quarterly", "governance", None),
    ("fleet_max_leverage", 0.6, "x",
     "doctrine (effective leverage cap)", None, None,
     "quarterly", "governance", None),
]


class DoctrineRegistry:
    """Append-only, versioned, provenance-complete constant store."""

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.executescript(SCHEMA)
        self._seed_if_empty()

    # -- seeding ------------------------------------------------------------
    def _seed_if_empty(self) -> None:
        cur = self.conn.execute("SELECT COUNT(*) FROM doctrine_constants")
        if cur.fetchone()[0] > 0:
            return
        now = time.time_ns()
        for (name, value, unit, prov, lo, hi, cadence, owner, ref) in SEED:
            self.conn.execute(
                "INSERT INTO doctrine_constants "
                "(name, version, value, unit, provenance, ci_lo, ci_hi, "
                " installed_ns, cadence, owner, amendment_ref) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (name, 1, value, unit, prov, lo, hi, now, cadence, owner, ref))
        self.conn.execute(
            "INSERT INTO registry_log (ts_ns, event, detail) VALUES (?,?,?)",
            (now, "SEED", f"{len(SEED)} constants installed (v1 each)"))
        self.conn.commit()

    # -- read ---------------------------------------------------------------
    def get(self, name: str) -> DoctrineConstant:
        cur = self.conn.execute(
            "SELECT name, version, value, unit, provenance, ci_lo, ci_hi, "
            "installed_ns, cadence, owner, amendment_ref "
            "FROM doctrine_constants WHERE name=? ORDER BY version DESC "
            "LIMIT 1", (name,))
        row = cur.fetchone()
        if row is None:
            raise KeyError(
                f"doctrine constant '{name}' not in registry — refusing to "
                f"fall back to an inline literal (P5)")
        return DoctrineConstant(*row)

    def value(self, name: str) -> float:
        return self.get(name).value

    def history(self, name: str) -> List[DoctrineConstant]:
        cur = self.conn.execute(
            "SELECT name, version, value, unit, provenance, ci_lo, ci_hi, "
            "installed_ns, cadence, owner, amendment_ref "
            "FROM doctrine_constants WHERE name=? ORDER BY version ASC",
            (name,))
        return [DoctrineConstant(*r) for r in cur.fetchall()]

    def all_latest(self) -> Dict[str, DoctrineConstant]:
        out: Dict[str, DoctrineConstant] = {}
        cur = self.conn.execute(
            "SELECT name, MAX(version) FROM doctrine_constants GROUP BY name")
        for (name, _v) in cur.fetchall():
            out[name] = self.get(name)
        return out

    # -- amendment (append-only) -------------------------------------------
    def install(self, name: str, value: float, provenance: str,
                cadence: str, owner: str, ci_lo: Optional[float] = None,
                ci_hi: Optional[float] = None,
                amendment_ref: Optional[str] = None) -> int:
        if not provenance or not cadence or not owner:
            raise ValueError(
                "P5: provenance, cadence and owner are mandatory")
        prev = self.conn.execute(
            "SELECT MAX(version) FROM doctrine_constants WHERE name=?",
            (name,)).fetchone()[0]
        version = (prev or 0) + 1
        unit = self.get(name).unit if prev else ""
        self.conn.execute(
            "INSERT INTO doctrine_constants "
            "(name, version, value, unit, provenance, ci_lo, ci_hi, "
            " installed_ns, cadence, owner, amendment_ref) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (name, version, value, unit, provenance, ci_lo, ci_hi,
             time.time_ns(), cadence, owner, amendment_ref))
        self.conn.execute(
            "INSERT INTO registry_log (ts_ns, event, detail) VALUES (?,?,?)",
            (time.time_ns(), "INSTALL",
             f"{name} v{version} = {value} ({provenance[:60]})"))
        self.conn.commit()
        return version

    # -- P5 audit -----------------------------------------------------------
    def audit_inline(self) -> List[Dict[str, str]]:
        """Catalog of known inline constants found in fleet source during the
        SZ-8 code read. Each entry is a P5 violation pending migration to the
        registry. This list is itself doctrine (grows only via amendment)."""
        return [
            {"const": "jump_threshold_bps=5.0", "site": "engine.py:1096",
             "governs": "lead-lag SNIPE trigger"},
            {"const": "min_sniping_edge_bps=5.0", "site": "engine.py:1097",
             "governs": "lead-lag SNIPE edge"},
            {"const": "v_100ms/1s/5s thresholds 1.5/3.5/7.5 bps",
             "site": "engine.py:162-164", "governs": "threat scanner"},
            {"const": "hawkes_eta_threshold=0.85", "site": "engine.py:165",
             "governs": "threat scanner eta gate"},
            {"const": "threat_cooldown_ns=15e9", "site": "engine.py:166",
             "governs": "threat cooldown"},
            {"const": "kinetic_z_threshold=2.5", "site": "engine.py:159",
             "governs": "QuadShield kinetic barrier"},
            {"const": "max_consecutive_fails=2", "site": "engine.py:1089",
             "governs": "markout doctor quarantine"},
            {"const": "max_corridor_drawdown_usd=0.0250",
             "site": "engine.py:1090", "governs": "markout doctor"},
            {"const": "quarantine_duration_sec=1800", "site": "engine.py:1091",
             "governs": "markout doctor quarantine"},
            {"const": "min_volume_usd=10_000_000", "site": "engine.py:1106",
             "governs": "universe screener volume filter"},
            {"const": "min_l1_depth_usd=1_500", "site": "engine.py:1107",
             "governs": "universe screener L1 filter (refuted as flat gate)"},
            {"const": "graduation req_snap = 30/(2*tau+26.4)",
             "site": "engine.py:1266", "governs": "snap law"},
        ]

    def close(self) -> None:
        self.conn.close()
