"""
SMOS V18 — CUT 2 / A2 VELOCITY SHIELD dt-NORMALIZATION PATCH
============================================================
File:      cut2/shield_dt_patch.py
Provenance: AUDIT.md §2 (the material defect: per-update EWMA decay)
Target:     engine.py SHA 6bb4b1f28ed47468... (verbatim fleet snapshot)
Registry:   vel_shield_tau_s = 2.0  (PROVISIONAL, provenance = cut2/AUDIT.md)

WHY (one paragraph)
-------------------
engine.py:291 decays the velocity mean/variance estimator by a FIXED 0.05 per
depth update. The estimator's half-life therefore scales with the corridor's
book-update rate (1.4 s at 10 upd/s, 13.9 s at 1 upd/s), so |z|>=3 does not mean
the same physical velocity on different corridors or feed regimes, and the
variance adapts at burst rate exactly during aggression events. This patch makes
the decay wall-clock: decay_t = 1 - exp(-dt/tau). The z-bands (2.0 / 3.0), the
clip ladder (0.75 / 0.50), retreat escalation, and the confirm gates are UNTOUCHED
- they are correct as built by the local AI.

SPLICE (6 lines changed at two sites) — apply to engine.py
----------------------------------------------------------
SITE 1 — state init, engine.py:249-252. REPLACE:

    # Graduated Velocity-Margin Shield state (Kinematic Trend Guard)
    self.vel_mean_bps: float = 0.0
    self.vel_var_bps: float = 25.0  # Prior variance (sigma = 5.0 bps/s)
    self.latest_z_vel: float = 0.0

WITH:

    # Graduated Velocity-Margin Shield state (Kinematic Trend Guard)
    # [cut2 dt-patch] wall-clock decay; tau registered PROVISIONAL (audit v1.0)
    self.vel_tau_s: float = float(self.cfg.get('vel_shield_tau_s', 2.0))
    self.vel_mean_bps: float = 0.0
    self.vel_var_bps: float = 25.0  # Prior variance (sigma = 5.0 bps/s)
    self.latest_z_vel: float = 0.0
    self.vel_last_ts_ms: Optional[int] = None

SITE 2 — update block, engine.py:289-296. REPLACE:

    # Update running velocity variance for normalized z_vel
    vel = self.py_kalman.velocity_bps
    decay = 0.05
    diff = vel - self.vel_mean_bps
    self.vel_mean_bps += decay * diff
    self.vel_var_bps = (1.0 - decay) * self.vel_var_bps + decay * (diff ** 2)
    sigma_vel = math.sqrt(max(1.0, self.vel_var_bps))
    self.latest_z_vel = (vel - self.vel_mean_bps) / sigma_vel

WITH:

    # [cut2 dt-patch] rate-invariant update: decay from elapsed wall-clock dt
    vel = self.py_kalman.velocity_bps
    dt_s = 0.0
    if self.vel_last_ts_ms is not None:
        dt_s = max(0.0, (venue_ms - self.vel_last_ts_ms) / 1000.0)
    self.vel_last_ts_ms = venue_ms
    decay = 1.0 - math.exp(-dt_s / self.vel_tau_s) if dt_s > 0.0 else 0.0
    if decay > 0.0:
        diff = vel - self.vel_mean_bps
        self.vel_mean_bps += decay * diff
        self.vel_var_bps = (1.0 - decay) * self.vel_var_bps + decay * (diff ** 2)
    sigma_vel = math.sqrt(max(1.0, self.vel_var_bps))
    self.latest_z_vel = (vel - self.vel_mean_bps) / sigma_vel

NOTES
-----
- venue_ms already exists at the update site (engine.py:268). Zero new imports.
- dt_s == 0 (duplicate timestamps in one burst) => decay 0 => no double-stepping
  inside a single update batch. This is the burst-clustering fix.
- Everything downstream (:485-507 consumption, :635/:666 rung clipping,
  :533 dispatcher feed) reads self.latest_z_vel unchanged.
- Rollback = revert both sites (keep the class below for the replay harness).

REPLAY (run on the box that owns task-41752's depth tape)
---------------------------------------------------------
After splicing, replay the 17:39:54 APR window through the live engine's
on_depth_update stream and assert: rung 2 and rung 3 entry orders never reach
update_quotes (rung 1 alone at clip 0.50, retreat=1, min_touch=3). The verbatim
incident shape is in cut3/fixtures_cut3.py::APR_WAVE_VERBATIM. Until that replay
runs locally, Cut 2 acceptance stands as STRUCTURAL PASS (AUDIT.md §5).
"""

from __future__ import annotations

import math
from typing import Optional


class RateInvariantVelocityZ:
    """Drop-in implementation of the patched state block (engine.py:249-296).

    Kept as a standalone class so (a) the patch logic is testable without the
    engine's unshipped dependencies, and (b) the APR replay harness can drive
    it directly off a recorded depth tape. The engine splice inlines the same
    math; this class is the reference implementation the tests certify.
    """

    __slots__ = ("tau_s", "mean_bps", "var_bps", "z", "_last_ts_ms", "_var_floor")

    def __init__(self, tau_s: float = 2.0, prior_var_bps: float = 25.0,
                 var_floor_bps: float = 1.0):
        self.tau_s = float(tau_s)
        self.mean_bps = 0.0
        self.var_bps = float(prior_var_bps)
        self.z = 0.0
        self._last_ts_ms: Optional[int] = None
        self._var_floor = float(var_floor_bps)

    def update(self, velocity_bps: float, ts_ms: int) -> float:
        """One estimator step. Returns the normalized z (also stored in .z)."""
        dt_s = 0.0
        if self._last_ts_ms is not None:
            dt_s = max(0.0, (int(ts_ms) - self._last_ts_ms) / 1000.0)
        self._last_ts_ms = int(ts_ms)

        decay = 1.0 - math.exp(-dt_s / self.tau_s) if dt_s > 0.0 else 0.0
        if decay > 0.0:
            diff = velocity_bps - self.mean_bps
            self.mean_bps += decay * diff
            self.var_bps = (1.0 - decay) * self.var_bps + decay * (diff ** 2)

        sigma = math.sqrt(max(self._var_floor, self.var_bps))
        self.z = (velocity_bps - self.mean_bps) / sigma
        return self.z

    # -- consumption-side reference (mirrors engine.py:485-507, unchanged) --

    def clip_mult(self) -> float:
        az = abs(self.z)
        if 2.0 <= az < 3.0:
            return 0.75
        if az >= 3.0:
            return 0.50
        return 1.0

    def band(self) -> int:
        az = abs(self.z)
        if 2.0 <= az < 3.0:
            return 1
        if az >= 3.0:
            return 2
        return 0

    def severe_pull(self, sentinel_drift_active: bool, book_heavy: bool) -> bool:
        """Hard side-pull iff |z|>=3 AND one confirming sensor (engine.py:503-507)."""
        return abs(self.z) >= 3.0 and (sentinel_drift_active or book_heavy)


class LegacyFixedDecayVelocityZ:
    """Pre-patch reference (engine.py:289-296 verbatim) — kept ONLY so the
    invariance test can print the pre/post divergence receipt."""

    __slots__ = ("mean_bps", "var_bps", "z", "decay")

    def __init__(self, decay: float = 0.05):
        self.mean_bps = 0.0
        self.var_bps = 25.0
        self.z = 0.0
        self.decay = float(decay)

    def update(self, velocity_bps: float, ts_ms: int) -> float:
        diff = velocity_bps - self.mean_bps
        self.mean_bps += self.decay * diff
        self.var_bps = (1.0 - self.decay) * self.var_bps + self.decay * (diff ** 2)
        sigma = math.sqrt(max(1.0, self.var_bps))
        self.z = (velocity_bps - self.mean_bps) / sigma
        return self.z
