"""
SMOS V18 — CUT 3 / BOOTSTRAP CORPUS (VERBATIM RECEIPTS ONLY)
=============================================================
Every record below is traceable to a shipped receipt. NO synthesized market
data (P5/M1: the census may only install numbers the tape actually printed).
Two corpora with different evidence power — the split is deliberate:

  R6 corpus  (edge ledger): 28 closed cycles with net PnL — enough for
      per-coin ledger MACHINERY, not enough for verdicts (max coin n = 12
      < 20 gate -> everything correctly lands UNPROVEN).
  S10 corpus (bounce census): 6 TIMED observations (entry ns + exit ns or
      bounded hold) — enough to exercise the KM estimator on real shapes,
      nowhere near the n>=30 census gate -> retirement correctly deferred.

SOURCES (all shipped / receipted):
  [A] task-41752 itemization, 28.2-min 20-corridor run, 23 fills — frozen in
      cut1/fixtures_task41752.py (CYCLES per symbol, net USD verbatim).
  [B] fill_tape_v17_database_and_records.md §3-§4: fills 71-80 with epoch-ns
      timestamps and trade_cycles verbatim rows (APR 3-rung short waterfall,
      OPG harvest, AZTEC decay exit).
  [C] task-41752 incident receipts in the worklog/SZ-6: ESPORTS +23.63 bps in
      2.0 s; HANA -140.73 bps CAT_STOP; GRAM PASSIVE_MAKER_HARVEST +16.04 bps
      average; APR rungs -83/-90/-98 bps at 17:38:40 and 17:39:54 waves.

DERIVED FIELDS (flagged in provenance, P5 discipline):
  - task-41752 pnl_bps: net_usd / $5.0 min-slot notional * 10^4 (the run's
    quoting clip). The telemetry's own bps prints (source [C]) are used
    verbatim where they exist and cross-check the derivation.
  - exit_tier for task-41752 cycles: printed where receipted ([C]); otherwise
    'UNRECEIPTED' — honest absence, not invention.
  - Bounce targets: spread-at-fill unknown for the historicals -> 4.0 bps
    (half of the 8.0 bps corridor cfg default; PROVISIONAL, census-pending).
"""

from s10_fill_tape_recorder import FillObservation
from r6_edge_accountant import CycleRecord

# ---------------------------------------------------------------------------
# [A] task-41752 closed cycles — net USD verbatim; pnl_bps derived @ $5.0
# ---------------------------------------------------------------------------

T41752_MIN_SLOT_USD = 5.0

# (symbol, net_usd, exit_tier, provenance-note)
_T41752 = [
    ("GRAMUSDT", 0.0083, "PASSIVE_MAKER_HARVEST", "cut1 fixtures CYCLES"),
    ("GRAMUSDT", 0.0117, "PASSIVE_MAKER_HARVEST", "cut1 fixtures CYCLES"),
    ("GRAMUSDT", 0.0294, "PASSIVE_MAKER_HARVEST", "cut1 fixtures CYCLES"),
    ("GRAMUSDT", 0.0015, "PASSIVE_MAKER_HARVEST", "cut1 fixtures CYCLES"),
    ("GRAMUSDT", 0.0049, "PASSIVE_MAKER_HARVEST", "cut1 fixtures CYCLES"),
    ("GRAMUSDT", 0.0159, "PASSIVE_MAKER_HARVEST", "cut1 fixtures CYCLES"),
    ("MITOUSDT", -0.0064, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("MITOUSDT", 0.0078, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("ESPORTSUSDT", 0.0120, "PASSIVE_MAKER_HARVEST",
     "+23.63 bps in 2.0 s printed (SZ-6 receipt); $5-slot derivation 24.0"),
    ("ATUSDT", -0.0018, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("ATUSDT", 0.0078, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("ATUSDT", -0.0051, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("ATUSDT", -0.0019, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("APRUSDT", -0.0032, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("APRUSDT", -0.0054, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("APRUSDT", -0.0018, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("APRUSDT", -0.0126, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("APRUSDT", -0.0090, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("APRUSDT", -0.0107, "UNRECEIPTED", "cut1 fixtures CYCLES"),
    ("APRUSDT", -0.0499, "UNRECEIPTED", "rung tail, 17:38:40 wave"),
    ("APRUSDT", -0.0462, "UNRECEIPTED", "rung tail, 17:38:40 wave"),
    ("APRUSDT", -0.0839, "CAT_STOP", "deepest rung, 17:39:54 wave"),
    ("HANAUSDT", -0.0712, "CAT_STOP", "-140.73 bps printed (SZ-6 receipt)"),
]

# ---------------------------------------------------------------------------
# [B] DB-spec verbatim rows — timestamps epoch-ns, exact
# ---------------------------------------------------------------------------

# fills 73-78, APRUSDT, from fill_tape_v17_database_and_records.md §3
APR_FILL_NS = {
    73: 1790876954076715900,   # BUY  39 @ 0.13160
    74: 1790876954140355300,   # BUY  39 @ 0.13150
    75: 1790876954163583200,   # BUY  76 @ 0.13140
    76: 1790877152108280600,   # SELL 38 @ 0.13390  (short entry, rung 1)
    77: 1790877152129514000,   # SELL 38 @ 0.13400  (short entry, rung 2)
    78: 1790877152186693100,   # SELL 75 @ 0.13410  (short entry, rung 3)
}

OPG_ENTRY_FILL_NS = 1790878579097777100    # fill 79: SELL 40 @ 0.1291
AZTEC_ENTRY_FILL_NS = 1790879000778457400  # fill 80: SELL 288 @ 0.01755

# The APR 3-rung short waterfall, trade_cycles verbatim (§4):
# entries 0.13410/0.13400/0.13390, exit 0.13470, holds 0.45/0.50/0.53 s,
# -48.35/-55.85/-63.36 bps, resolution PASSIVE_MAKER_HARVEST.
APR_WAVE_VERBATIM = [
    {"entry_px": 0.13410, "qty": 75.0, "hold_s": 0.53, "pnl_bps": -48.35},
    {"entry_px": 0.13400, "qty": 38.0, "hold_s": 0.50, "pnl_bps": -55.85},
    {"entry_px": 0.13390, "qty": 38.0, "hold_s": 0.45, "pnl_bps": -63.36},
]

# OPG harvest verbatim: entry SELL 40 @ 0.1291, exit 0.12890, +11.89 bps,
# hold 2.36 s, PASSIVE_MAKER_HARVEST.
OPG_HARVEST_VERBATIM = {"entry_px": 0.12910, "qty": 40.0, "hold_s": 2.36,
                        "exit_px": 0.12890, "pnl_bps": +11.89}

# AZTEC decay exit verbatim: entry SELL 288 @ 0.01755, exit 0.01758,
# -20.70 bps, hold 47.00 s, PASSIVE_MAKER_HARVEST.
AZTEC_DECAY_VERBATIM = {"entry_px": 0.01755, "qty": 288.0, "hold_s": 47.00,
                        "exit_px": 0.01758, "pnl_bps": -20.70}


# ---------------------------------------------------------------------------
# corpus builders
# ---------------------------------------------------------------------------

def r6_bootstrap_cycles():
    """28 CycleRecords: 23 from task-41752 + 5 DB-spec verbatim cycles."""
    recs = []
    for (sym, usd, tier, _note) in _T41752:
        recs.append(CycleRecord(
            corridor=sym,
            pnl_bps=round(usd / T41752_MIN_SLOT_USD * 10000.0, 2),
            exit_tier=tier, is_taker=False, net_usd=usd))
    # [B] DB-spec cycles (bps verbatim)
    for w in APR_WAVE_VERBATIM:
        recs.append(CycleRecord(
            corridor="APRUSDT", pnl_bps=w["pnl_bps"],
            exit_tier="PASSIVE_MAKER_HARVEST", is_taker=False,
            net_usd=round(w["pnl_bps"] / 10000.0 * w["entry_px"] * w["qty"], 6)))
    recs.append(CycleRecord(
        corridor="OPGUSDT", pnl_bps=OPG_HARVEST_VERBATIM["pnl_bps"],
        exit_tier="PASSIVE_MAKER_HARVEST", is_taker=False,
        net_usd=round(OPG_HARVEST_VERBATIM["pnl_bps"] / 10000.0
                      * OPG_HARVEST_VERBATIM["entry_px"]
                      * OPG_HARVEST_VERBATIM["qty"], 6)))
    recs.append(CycleRecord(
        corridor="AZTECUSDT", pnl_bps=AZTEC_DECAY_VERBATIM["pnl_bps"],
        exit_tier="PASSIVE_MAKER_HARVEST", is_taker=False,
        net_usd=round(AZTEC_DECAY_VERBATIM["pnl_bps"] / 10000.0
                      * AZTEC_DECAY_VERBATIM["entry_px"]
                      * AZTEC_DECAY_VERBATIM["qty"], 6)))
    return recs


def s10_bootstrap_observations():
    """6 timed FillObservations (EXIT_BOUNDED evidence mode).

    APR x3: adverse exits at 0.45/0.50/0.53 s -> CENSORED (no bounce).
    OPG: favorable exit (+11.89 bps >= 4.0 target) at 2.36 s -> onset <= 2.36.
    ESPORTS [C]: +23.63 bps in 2.0 s -> onset <= 2.0 s.
    AZTEC: adverse exit at 47 s -> CENSORED.
    """
    obs = []
    base = APR_FILL_NS[76]
    for i, w in enumerate(APR_WAVE_VERBATIM):
        fill_ns = APR_FILL_NS[76 + i]
        obs.append(FillObservation(
            fill_id=f"APRWAVE_{76 + i}", corridor="APRUSDT",
            ts_ns=fill_ns, side="SELL", entry_px=w["entry_px"],
            qty=w["qty"], spread_bps_at_fill=None,
            exit_px=0.13470, exit_ns=fill_ns + int(w["hold_s"] * 1e9),
            exit_tier="PASSIVE_MAKER_HARVEST", net_pnl_bps=w["pnl_bps"],
            regime_at_entry="WATERFALL",
            shield_state_at_entry="Z_VEL_UNPATCHED"))
    obs.append(FillObservation(
        fill_id="OPG_79", corridor="OPGUSDT", ts_ns=OPG_ENTRY_FILL_NS,
        side="SELL", entry_px=OPG_HARVEST_VERBATIM["entry_px"],
        qty=OPG_HARVEST_VERBATIM["qty"], spread_bps_at_fill=None,
        exit_px=OPG_HARVEST_VERBATIM["exit_px"],
        exit_ns=OPG_ENTRY_FILL_NS
        + int(OPG_HARVEST_VERBATIM["hold_s"] * 1e9),
        exit_tier="PASSIVE_MAKER_HARVEST",
        net_pnl_bps=OPG_HARVEST_VERBATIM["pnl_bps"],
        regime_at_entry="CALM", shield_state_at_entry="QUIET"))
    # ESPORTS task-41752 receipt [C]: ts unavailable -> anchored at run close
    # of the task-41752 window with explicit provenance note.
    obs.append(FillObservation(
        fill_id="ESPORTS_T41752", corridor="ESPORTSUSDT",
        ts_ns=0, side="SELL", entry_px=0.01098, qty=455.0,
        spread_bps_at_fill=None,
        exit_px=None,
        exit_ns=int(ESPORTS_HOLD_S * 1e9),
        exit_tier="PASSIVE_MAKER_HARVEST", net_pnl_bps=+23.63,
        regime_at_entry="CALM", shield_state_at_entry="QUIET"))
    obs.append(FillObservation(
        fill_id="AZTEC_80", corridor="AZTECUSDT",
        ts_ns=AZTEC_ENTRY_FILL_NS, side="SELL",
        entry_px=AZTEC_DECAY_VERBATIM["entry_px"],
        qty=AZTEC_DECAY_VERBATIM["qty"], spread_bps_at_fill=None,
        exit_px=AZTEC_DECAY_VERBATIM["exit_px"],
        exit_ns=AZTEC_ENTRY_FILL_NS
        + int(AZTEC_DECAY_VERBATIM["hold_s"] * 1e9),
        exit_tier="PASSIVE_MAKER_HARVEST",
        net_pnl_bps=AZTEC_DECAY_VERBATIM["pnl_bps"],
        regime_at_entry="DRIFT", shield_state_at_entry="QUIET"))
    return obs


ESPORTS_HOLD_S = 2.0   # [C] "+23.63 bps in 2.0 s"

FORTRESS_COHORT = ["GRAMUSDT", "ESPORTSUSDT", "MITOUSDT", "ATUSDT"]
THIN_COHORT = ["HANAUSDT", "APRUSDT"]
