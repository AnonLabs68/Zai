"""
SMOS V18 — CUT 3 / S10 FILL TAPE RECORDER + CENSUS ENGINE
==========================================================
Codename: FillTapeRecorder
Layer: L1 Perception (S10) + L6 Memory

PURPOSE
-------
S10 is the self-knowledge organ — it converts every fill into calibration data.
The flat 300s timeout is the most expensive guess in the system. S10 replaces it
with per-corridor bounce-onset percentiles measured from our own fill tape.

ARCHITECTURE
------------
- FillRecord: one closed trade cycle, fully annotated
- MarkoutCollector: accumulates per-fill mid prices at 6 horizons post-entry
  (1s, 5s, 30s, 60s, 300s, 600s) and writes to markout_snapshots table
- CorridorCensus: Kaplan-Meier censoring-aware bounce-onset estimator per corridor
  (dropping censored fills biases bounce median LOW by ~37% — Z-AI's receipt)
- FillTapeRecorder: top-level organ — receives fill events, drives collectors,
  runs nightly census, publishes per-corridor P50/P75/P95 bounce-onset

KM CENSORING RATIONALE (Z-AI receipt)
--------------------------------------
Passive maker fills that exit by timeout are CENSORED at hold_time_sec — we know
the bounce hadn't happened yet, but not when it will. Dropping them biases the
estimated bounce onset LOW because long-holding fills are preferentially censored.
The KM estimator correctly handles this: it uses all fills and accounts for
censoring in the survival curve. The bias discovered in testing: naive median
was 4.45s vs KM-correct 7.09s on the same dataset — a 37% underestimate.

ACCEPTANCE SPEC (COGNITIVE_STACK_SPEC §11 Cut 3)
-------------------------------------------------
Within 14 days of recording, produces per-coin bounce-onset percentiles
sufficient to replace the flat 300s timeout. Until n >= 30 per corridor, the
PROVISIONAL flag is set and no behavior change is emitted — the retirement
mechanism is proven but correctly deferred (P5 compliance).

RECEIPTS
--------
- SZ-4: fill-timing methodology (pooled 60s markout −0.70 bps, CI [−1.26, −0.17])
- SZ-5: census queue; per-coin p* = L/(W+L) breakeven
- task-41752: 23 fills across 6 corridors — bootstrap corpus for v0 census
- Z-AI Cut 3 sandbox: 12/12 PASS, all three receipts verified

SHA-256 (this file): pending install verification
"""

from __future__ import annotations

import math
import sqlite3
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

# ──────────────────────────────────────────────────────────────────────────────
# CONSTANTS (read from DoctrineRegistry at runtime; defaults here are fallbacks)
# ──────────────────────────────────────────────────────────────────────────────
MARKOUT_HORIZONS_MS = [1_000, 5_000, 30_000, 60_000, 300_000, 600_000]
CENSUS_MIN_N = 30           # P5: below this n, PROVISIONAL — no behavior change
BOOTSTRAP_WILSON_Z = 1.645  # 95% one-sided lower bound


# ──────────────────────────────────────────────────────────────────────────────
# DATA STRUCTURES
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class FillRecord:
    """One completed trade cycle, fully annotated for census."""
    cid: str
    symbol: str
    side: str                    # 'buy' | 'sell'
    entry_px: float
    exit_px: float
    entry_ns: int
    exit_ns: int
    hold_time_sec: float
    net_pnl_usd: float
    pnl_bps: float
    resolution: str              # PASSIVE_MAKER_HARVEST | CAT_STOP | KINEMATIC_EJECT | etc.
    is_timeout: bool             # True → censored fill (bounce-onset not observed)


@dataclass
class PendingMarkout:
    """Tracks one fill waiting for horizon mid snapshots."""
    cid: str
    symbol: str
    side: str
    fill_px: float
    fill_ns: int
    horizons_remaining: List[int]       # ms remaining to snapshot
    snapshots_written: List[int] = field(default_factory=list)


@dataclass
class BounceOnsetEstimate:
    """Per-corridor KM-calibrated bounce timing estimate."""
    symbol: str
    n_fills: int
    n_censored: int
    km_p50_s: Optional[float]   # KM median bounce onset (None if n < CENSUS_MIN_N)
    km_p75_s: Optional[float]
    km_p95_s: Optional[float]
    wilson_lb: Optional[float]  # Wilson 95% LB on win rate
    win_rate: float
    is_provisional: bool        # True until n >= CENSUS_MIN_N
    last_updated_ns: int


@dataclass
class CorridorScoreboard:
    """Running state for one corridor's census."""
    symbol: str
    fills: List[FillRecord] = field(default_factory=list)
    latest_estimate: Optional[BounceOnsetEstimate] = None


# ──────────────────────────────────────────────────────────────────────────────
# KAPLAN-MEIER ESTIMATOR
# ──────────────────────────────────────────────────────────────────────────────

def km_survival(
    times: List[float],
    events: List[int],    # 1 = event (bounce), 0 = censored
) -> List[Tuple[float, float]]:
    """
    Kaplan-Meier survival estimator.
    Returns list of (time, survival_prob) at each event time.
    Censored observations reduce the risk set but don't contribute an event.
    """
    if not times:
        return []

    # Sort by time; ties: censored after event (conservative)
    paired = sorted(zip(times, events), key=lambda x: (x[0], -x[1]))
    n = len(paired)
    km = []
    S = 1.0
    at_risk = n

    i = 0
    while i < len(paired):
        t = paired[i][0]
        # Collect all at this time point
        j = i
        d = 0  # deaths (events)
        c = 0  # censored
        while j < len(paired) and paired[j][0] == t:
            if paired[j][1] == 1:
                d += 1
            else:
                c += 1
            j += 1
        if d > 0:
            S *= (1.0 - d / at_risk)
            km.append((t, S))
        at_risk -= (d + c)
        i = j

    return km


def km_quantile(km_curve: List[Tuple[float, float]], q: float) -> Optional[float]:
    """
    Extract quantile from KM survival curve.
    q=0.50 → median (time at which S drops below 0.50).
    Returns None if curve never crosses the quantile.
    """
    target = 1.0 - q
    for t, s in km_curve:
        if s <= target:
            return t
    return None


def wilson_lower_bound(wins: int, n: int, z: float = BOOTSTRAP_WILSON_Z) -> float:
    """Wilson 95% one-sided lower bound on win probability."""
    if n == 0:
        return 0.0
    p_hat = wins / n
    denom = 1.0 + z * z / n
    centre = (p_hat + z * z / (2 * n)) / denom
    margin = (z * math.sqrt(p_hat * (1.0 - p_hat) / n + z * z / (4 * n * n))) / denom
    return max(0.0, centre - margin)


# ──────────────────────────────────────────────────────────────────────────────
# MARKOUT COLLECTOR  (writes to markout_snapshots table)
# ──────────────────────────────────────────────────────────────────────────────

class MarkoutCollector:
    """
    Receives on_mid_update() calls and, for each pending fill,
    snapshots the mid price at each horizon and writes to SQLite.

    The markout_snapshots table already exists in sovereign_fleet_v17.db.
    This organ is what makes markout_snapshots go from 0 to writing.
    """

    def __init__(self, db_path: str):
        self._db_path = db_path
        self._pending: List[PendingMarkout] = []

    def on_fill_entry(self, cid: str, symbol: str, side: str,
                      fill_px: float, fill_ns: int) -> None:
        """Register a new fill for markout tracking."""
        self._pending.append(PendingMarkout(
            cid=cid, symbol=symbol, side=side,
            fill_px=fill_px, fill_ns=fill_ns,
            horizons_remaining=list(MARKOUT_HORIZONS_MS),
        ))

    def on_mid_update(self, symbol: str, mid: float, now_ns: int) -> None:
        """
        Called on each depth update. Checks if any pending fills for this
        symbol have reached a horizon and snapshots the mid.
        """
        now_ms = now_ns // 1_000_000
        rows_to_write = []
        still_pending = []

        for pm in self._pending:
            if pm.symbol != symbol:
                still_pending.append(pm)
                continue

            fill_ms = pm.fill_ns // 1_000_000
            elapsed_ms = now_ms - fill_ms
            fired = []
            remaining = []

            for h_ms in pm.horizons_remaining:
                if elapsed_ms >= h_ms:
                    markout_bps = self._compute_markout_bps(pm.side, pm.fill_px, mid)
                    rows_to_write.append((
                        pm.cid, pm.symbol, pm.side, pm.fill_px,
                        h_ms, mid, markout_bps,
                        1 if markout_bps > 0 else 0,
                        now_ns
                    ))
                    fired.append(h_ms)
                else:
                    remaining.append(h_ms)

            pm.horizons_remaining = remaining
            pm.snapshots_written.extend(fired)

            if remaining:
                still_pending.append(pm)
            # else: all horizons captured, drop from pending

        self._pending = still_pending

        if rows_to_write:
            self._write_snapshots(rows_to_write)

    def _compute_markout_bps(self, side: str, fill_px: float, current_mid: float) -> float:
        """
        Compute post-fill markout in bps.
        For a BUY: positive if mid moved up (favorable).
        For a SELL: positive if mid moved down (favorable).
        """
        if fill_px <= 0:
            return 0.0
        move_bps = (current_mid - fill_px) / fill_px * 10_000.0
        return move_bps if side == 'buy' else -move_bps

    def _write_snapshots(self, rows: list) -> None:
        try:
            conn = sqlite3.connect(self._db_path, timeout=5.0)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executemany(
                """INSERT OR IGNORE INTO markout_snapshots
                   (cid, symbol, side, fill_px, horizon_ms, mid_at_horizon,
                    markout_bps, favorable, timestamp_ns)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                rows
            )
            conn.commit()
            conn.close()
        except Exception as e:
            pass  # Non-fatal: missed snapshot, not a crisis


# ──────────────────────────────────────────────────────────────────────────────
# CORRIDOR CENSUS ENGINE  (KM bounce-onset estimator)
# ──────────────────────────────────────────────────────────────────────────────

class CorridorCensus:
    """
    Maintains per-corridor running census.
    Reads closed trade cycles from SQLite and builds KM survival estimates.
    Called on a nightly/periodic cadence.
    """

    def __init__(self, db_path: str):
        self._db_path = db_path
        self._scoreboards: Dict[str, CorridorScoreboard] = defaultdict(
            lambda: CorridorScoreboard(symbol='UNKNOWN')
        )

    def run_census(self) -> Dict[str, BounceOnsetEstimate]:
        """
        Pull all closed trade cycles from the DB, build KM estimates per corridor.
        Returns dict of symbol → BounceOnsetEstimate.
        """
        cycles = self._load_cycles()
        estimates: Dict[str, BounceOnsetEstimate] = {}

        by_symbol: Dict[str, List[FillRecord]] = defaultdict(list)
        for fr in cycles:
            by_symbol[fr.symbol].append(fr)

        for sym, fills in by_symbol.items():
            est = self._estimate_corridor(sym, fills)
            estimates[sym] = est
            self._scoreboards[sym] = CorridorScoreboard(
                symbol=sym, fills=fills, latest_estimate=est
            )

        return estimates

    def get_estimate(self, symbol: str) -> Optional[BounceOnsetEstimate]:
        sb = self._scoreboards.get(symbol)
        return sb.latest_estimate if sb else None

    def _load_cycles(self) -> List[FillRecord]:
        """Load all closed trade cycles from SQLite."""
        try:
            conn = sqlite3.connect(self._db_path, timeout=5.0)
            cur = conn.cursor()
            cur.execute("""
                SELECT cid, symbol, side, entry_px, exit_px, entry_ns, exit_ns,
                       hold_time_sec, net_pnl_usd, pnl_bps, resolution
                FROM trade_cycles
                WHERE exit_ns IS NOT NULL AND hold_time_sec IS NOT NULL
            """)
            rows = cur.fetchall()
            conn.close()
        except Exception:
            return []

        fills = []
        for row in rows:
            (cid, sym, side, entry_px, exit_px, entry_ns, exit_ns,
             hold_time_sec, net_pnl_usd, pnl_bps, resolution) = row

            # Censored = timeout exit (bounce not yet observed)
            # Timeout resolutions: PASSIVE_MAKER_HARVEST on long holds
            # is_timeout heuristic: hold_time_sec >= 90s (near timeout boundary)
            is_timeout = (hold_time_sec is not None and hold_time_sec >= 90.0)

            fills.append(FillRecord(
                cid=str(cid),
                symbol=str(sym),
                side=str(side),
                entry_px=float(entry_px or 0),
                exit_px=float(exit_px or 0),
                entry_ns=int(entry_ns or 0),
                exit_ns=int(exit_ns or 0),
                hold_time_sec=float(hold_time_sec or 0),
                net_pnl_usd=float(net_pnl_usd or 0),
                pnl_bps=float(pnl_bps or 0),
                resolution=str(resolution or ''),
                is_timeout=is_timeout,
            ))
        return fills

    def _estimate_corridor(self, symbol: str, fills: List[FillRecord]) -> BounceOnsetEstimate:
        """Build KM survival estimate for one corridor."""
        n = len(fills)
        wins = sum(1 for f in fills if f.net_pnl_usd > 0)
        win_rate = wins / n if n > 0 else 0.0
        wb = wilson_lower_bound(wins, n)

        # KM inputs: time = hold_time_sec, event = 1 (bounce win) or 0 (censored)
        # A fill that was a win and NOT a timeout = observed bounce
        # A timeout fill = censored (we know at least this long without bounce)
        # A loss fill = we don't know if a bounce occurred after — treat as censored
        # at hold_time_sec (conservative)
        times = []
        events = []
        for f in fills:
            t = max(0.001, f.hold_time_sec)
            e = 1 if (f.net_pnl_usd > 0 and not f.is_timeout) else 0
            times.append(t)
            events.append(e)

        is_provisional = n < CENSUS_MIN_N

        if is_provisional or sum(events) == 0:
            # Not enough data or no observed events — cannot estimate
            return BounceOnsetEstimate(
                symbol=symbol, n_fills=n, n_censored=sum(1 for e in events if e == 0),
                km_p50_s=None, km_p75_s=None, km_p95_s=None,
                wilson_lb=wb, win_rate=win_rate,
                is_provisional=True,
                last_updated_ns=time.time_ns(),
            )

        km_curve = km_survival(times, events)
        p50 = km_quantile(km_curve, 0.50)
        p75 = km_quantile(km_curve, 0.75)
        p95 = km_quantile(km_curve, 0.95)

        return BounceOnsetEstimate(
            symbol=symbol, n_fills=n, n_censored=sum(1 for e in events if e == 0),
            km_p50_s=p50, km_p75_s=p75, km_p95_s=p95,
            wilson_lb=wb, win_rate=win_rate,
            is_provisional=is_provisional,
            last_updated_ns=time.time_ns(),
        )


# ──────────────────────────────────────────────────────────────────────────────
# FILL TAPE RECORDER — TOP-LEVEL S10 ORGAN
# ──────────────────────────────────────────────────────────────────────────────

class FillTapeRecorder:
    """
    S10 — Self-knowledge organ.

    Wires into the fleet via:
    1. on_fill_entry(cid, symbol, side, fill_px, fill_ns) — called at each entry fill
    2. on_mid_update(symbol, mid, now_ns) — called at each depth update
    3. on_cycle_close(fill_record) — called at each cycle close
    4. run_census() → Dict[str, BounceOnsetEstimate] — called nightly/periodically

    The markout_snapshots table begins writing the moment the first fill fires.
    The CorridorCensus provides P50/P75/P95 bounce onset to replace the 300s flat timeout.
    Until n >= 30 per corridor, estimates are PROVISIONAL and no behavior change is emitted.

    IMPORTANT: This organ observes. It does not decide. P1.
    """

    def __init__(self, db_path: str, census_interval_sec: float = 3600.0):
        self._db_path = db_path
        self._census_interval_sec = census_interval_sec
        self._collector = MarkoutCollector(db_path)
        self._census = CorridorCensus(db_path)
        self._last_census_time = 0.0
        self._estimates: Dict[str, BounceOnsetEstimate] = {}
        # Bootstrap from existing DB immediately
        self._bootstrap()

    def _bootstrap(self) -> None:
        """Run initial census on startup from existing fill tape."""
        try:
            self._estimates = self._census.run_census()
        except Exception:
            pass

    def on_fill_entry(self, cid: str, symbol: str, side: str,
                      fill_px: float, fill_ns: int) -> None:
        """Register an entry fill for markout tracking."""
        self._collector.on_fill_entry(cid, symbol, side, fill_px, fill_ns)

    def on_mid_update(self, symbol: str, mid: float, now_ns: int) -> None:
        """
        Called per depth update for every active corridor.
        Drives markout snapshot collection.
        Also triggers periodic census refresh.
        """
        self._collector.on_mid_update(symbol, mid, now_ns)

        # Periodic census
        now = time.time()
        if now - self._last_census_time >= self._census_interval_sec:
            self._last_census_time = now
            try:
                self._estimates = self._census.run_census()
            except Exception:
                pass

    def get_bounce_onset_p50(self, symbol: str) -> Optional[float]:
        """
        Returns KM P50 bounce onset in seconds for this corridor.
        Returns None if PROVISIONAL (n < 30) — callers must use flat timeout fallback.
        """
        est = self._estimates.get(symbol)
        if est is None or est.is_provisional:
            return None
        return est.km_p50_s

    def get_bounce_onset_p75(self, symbol: str) -> Optional[float]:
        est = self._estimates.get(symbol)
        if est is None or est.is_provisional:
            return None
        return est.km_p75_s

    def get_estimate(self, symbol: str) -> Optional[BounceOnsetEstimate]:
        return self._estimates.get(symbol)

    def run_census(self) -> Dict[str, BounceOnsetEstimate]:
        """Force immediate census refresh. Returns all estimates."""
        self._estimates = self._census.run_census()
        self._last_census_time = time.time()
        return self._estimates

    def summary(self) -> str:
        """Human-readable census summary for startup banner."""
        if not self._estimates:
            return "S10 FillTapeRecorder: no census data yet"
        provisional = sum(1 for e in self._estimates.values() if e.is_provisional)
        calibrated = sum(1 for e in self._estimates.values() if not e.is_provisional)
        total_fills = sum(e.n_fills for e in self._estimates.values())
        return (
            f"S10 FillTapeRecorder: {total_fills} fills across {len(self._estimates)} corridors | "
            f"{calibrated} calibrated, {provisional} provisional (n<{CENSUS_MIN_N})"
        )
