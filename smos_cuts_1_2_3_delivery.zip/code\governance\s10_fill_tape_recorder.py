"""
SMOS V18 — CUT 3 / S10 FILL-TAPE RECORDER + BOUNCE CENSUS
=========================================================
Spec: COGNITIVE_STACK_SPEC.md §4 S10 (the self-knowledge organ), §9 L6
fill_census schema, §11 Cut 3 acceptance ("14-day bounce-onset percentiles
replace flat 300s").

WHAT THIS ORGAN DOES
--------------------
Every entry fill becomes an OBSERVATION. Post-fill, it records:
  - markout curve at 1/5/30/60/300/1800 s horizons (markout_snapshots table —
    the table that has existed with 0 rows; this organ makes it write)
  - adverse excursion (worst markout over the observation window)
  - bounce-onset: time until price returns far enough to realize the passive
    edge (markout >= +half-spread at fill), or CENSORED if the cycle exits
    first (adverse exits never bounced before ejecting)

Bounce-onset percentiles are estimated per corridor with a KAPLAN-MEIER
survival estimator — the only statistically honest tool for this data,
because adverse exits are right-censored observations (the bounce might have
happened at t > exit; we will never know). A naive mean-of-observed-bounces
would be biased downward exactly on the toxic corridors we care about most.

Two evidence modes (pre-registered, per-row provenance):
  MID_PATH      live mode: recorder saw post-fill mids -> exact onset
  EXIT_BOUNDED  historical bootstrap mode: no mid tape -> a favorable exit
                (net_bps >= bounce target) proves onset <= hold_time, an
                adverse exit censors at hold_time. Onsets are UPPER bounds ->
                P50 conservative (longer T1 cadence) -> fails safe (holds
                slightly longer, never ejects faster, on thin evidence).

REGISTRY HOOK (the 300s retirement):
    t_base_s = float(self.timeout_sec) if ... else 420.0          # BEFORE
    if self.bounce_census is not None:                            # AFTER
        t_base_s = self.bounce_census.t1_cadence_s(self.symbol, fallback=t_base_s)
CENSUSED coins (n >= 30 AND KM P50 CI width <= 50% of P50) get
clamp(1.25 * P50, 30, 900); everyone else keeps the incumbent flat timeout.
Zero behavior change until the census earns its numbers (P5).

SQLite: WAL, synchronous=NORMAL (matches the fleet DB spec), append-only (B5).
"""

from __future__ import annotations

import json
import math
import sqlite3
from dataclasses import dataclass, field
from typing import Optional

HORIZONS_S = (1.0, 5.0, 30.0, 60.0, 300.0, 1800.0)

# ---- pre-registered census gate + cadence law (doctrine registry seeds) ----
CENSUS_MIN_N = 30              # per-coin fills before a theta may flip state
CENSUS_MAX_CI_FRAC = 0.50      # KM P50 95% CI width <= 50% of P50
T1_P50_MULTIPLIER = 1.25       # T1 walk cadence = 1.25 x bounce-onset P50
T1_CADENCE_FLOOR_S = 30.0
T1_CADENCE_CAP_S = 900.0
AE_MIN_N = 20                  # adverse-excursion P75 (T2 bound) sample gate
DEFAULT_BOUNCE_TARGET_BPS = 4.0  # half of 8.0 bps cfg spread; PROVISIONAL

FILL_CENSUS_DDL = """
CREATE TABLE IF NOT EXISTS fill_census (
    fill_id TEXT PRIMARY KEY,
    corridor TEXT NOT NULL,
    ts_ns INTEGER NOT NULL,
    side TEXT NOT NULL,
    entry_px REAL NOT NULL,
    exit_px REAL,
    exit_tier TEXT,
    adverse_excursion_bps REAL,
    bounce_onset_s REAL,
    markout_1s_bps REAL, markout_5s_bps REAL, markout_30s_bps REAL,
    markout_60s_bps REAL, markout_300s_bps REAL, markout_1800s_bps REAL,
    regime_at_entry TEXT, shield_state_at_entry TEXT,
    bounce_target_bps REAL NOT NULL,
    evidence_mode TEXT NOT NULL,
    censored INTEGER NOT NULL,
    provenance TEXT NOT NULL
);
"""

MARKOUT_SNAPSHOTS_DDL = """
CREATE TABLE IF NOT EXISTS markout_snapshots (
    snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT,
    fill_id TEXT NOT NULL,
    corridor TEXT NOT NULL,
    horizon_s REAL NOT NULL,
    markout_bps REAL,
    ts_ns INTEGER NOT NULL
);
"""


# ============================================================= observation =

@dataclass
class FillObservation:
    fill_id: str
    corridor: str
    ts_ns: int
    side: str                     # 'BUY' | 'SELL' (entry direction)
    entry_px: float
    qty: float
    spread_bps_at_fill: Optional[float] = None
    regime_at_entry: str = "UNKNOWN"
    shield_state_at_entry: str = "UNKNOWN"
    # settlement facts (queue_broker trade-cycle close)
    exit_px: Optional[float] = None
    exit_ns: Optional[int] = None
    exit_tier: Optional[str] = None
    net_pnl_bps: Optional[float] = None
    # live mid tape (optional; historical mode omits it)
    mid_path: list = field(default_factory=list)   # [(ts_ns, mid_px)]

    @property
    def bounce_target_bps(self) -> float:
        if self.spread_bps_at_fill is not None:
            return 0.5 * self.spread_bps_at_fill
        return DEFAULT_BOUNCE_TARGET_BPS

    def markout_bps(self, px: float) -> float:
        if self.side.upper() == "BUY":
            return (px - self.entry_px) / self.entry_px * 10000.0
        return (self.entry_px - px) / self.entry_px * 10000.0


# ============================================================== estimator =

class KaplanMeier:
    """Kaplan-Meier survival estimator with Greenwood variance and
    complementary log-log 95% CIs. Small, exact, no dependencies.

    events: observed bounce times (list of float seconds)
    censored: right-censoring times (exited before bounce; float seconds)
    """

    def __init__(self, events: list, censored: list):
        self.events = list(events)
        self.censored = list(censored)
        # pooled distinct event times with at-risk counts
        times = sorted(set(self.events))
        n_at_time = {}
        for t in times:
            at_risk = sum(1 for e in self.events if e >= t) + \
                      sum(1 for c in self.censored if c >= t)
            d = sum(1 for e in self.events if e == t)
            n_at_time[t] = (at_risk, d)
        self._table = n_at_time
        self.n_total = len(self.events) + len(self.censored)

    def survival(self, t: float) -> float:
        s = 1.0
        for et, (n, d) in self._table.items():
            if et <= t and n > 0:
                s *= (1.0 - d / n)
        return s

    def _greenwood_var(self, t: float) -> float:
        """Greenwood variance of S(t)."""
        s = self.survival(t)
        acc = 0.0
        for et, (n, d) in self._table.items():
            if et <= t and n > 0 and d < n:
                acc += d / (n * (n - d))
        return s * s * acc

    def survival_ci(self, t: float) -> tuple:
        """Complementary log-log 95% CI for S(t)."""
        s = self.survival(t)
        if s >= 1.0 or s <= 0.0 or self.n_total == 0:
            return (s, s)
        var = self._greenwood_var(t)
        if var <= 0.0:
            return (s, s)
        se_loglog = math.sqrt(var) / (s * abs(math.log(s)))
        z = 1.959964
        lo = s ** math.exp(z * se_loglog)
        hi = s ** math.exp(-z * se_loglog)
        return (max(0.0, lo), min(1.0, hi))

    def median(self) -> tuple:
        """Returns (p50, ci_lo, ci_hi). p50 = None if S never crosses 0.5.

        CI derivation: m is in the median CI iff 0.5 lies inside the CI of
        S(m), i.e. S_lo(m) <= 0.5 <= S_hi(m). As m grows the S-bands fall, so
        the CI is [first m with S_lo(m) <= 0.5, first m with S_hi(m) <= 0.5].
        """
        if self.n_total == 0:
            return (None, None, None)
        times = sorted(set(self.events + self.censored))
        p50 = None
        for t in times:
            if self.survival(t) <= 0.5:
                p50 = t
                break
        if p50 is None:
            return (None, None, None)
        ci_lo = ci_hi = None
        for t in times:
            s_lo, _ = self.survival_ci(t)
            if s_lo <= 0.5:
                ci_lo = t
                break
        for t in times:
            _, s_hi = self.survival_ci(t)
            if s_hi <= 0.5:
                ci_hi = t
                break
        return (p50, ci_lo, ci_hi)


# ================================================================= census =

@dataclass
class CoinCensus:
    corridor: str
    n: int
    n_events: int
    n_censored: int
    p50_s: Optional[float]
    ci: tuple
    ae_p75_bps: Optional[float]
    ae_n: int
    status: str                    # 'PROVISIONAL' | 'CENSUSED' | 'NO_BOUNCE'


class BounceCensus:
    """Consumed by queue_broker timeout (t1_cadence_s) and the doctrine
    registry amendment job (to_registry_amendment)."""

    def __init__(self, coin_censuses: dict, provenance: str):
        self.coins = dict(coin_censuses)
        self.provenance = str(provenance)

    def _cc(self, corridor: str) -> Optional[CoinCensus]:
        return self.coins.get(corridor)

    def t1_cadence_s(self, corridor: str, fallback: float) -> float:
        """THE queue_broker.py:426 replacement. Returns the census-calibrated
        T1 walk cadence only for CENSUSED corridors; everyone else keeps the
        incumbent flat timeout (zero behavior change until earned)."""
        cc = self._cc(corridor)
        if cc is None or cc.status != "CENSUSED" or cc.p50_s is None:
            return float(fallback)
        cadence = T1_P50_MULTIPLIER * cc.p50_s
        return min(T1_CADENCE_CAP_S, max(T1_CADENCE_FLOOR_S, cadence))

    def t2_excursion_bound_bps(self, corridor: str, fallback: float) -> float:
        cc = self._cc(corridor)
        if cc is None or cc.ae_n < AE_MIN_N or cc.ae_p75_bps is None:
            return float(fallback)
        return cc.ae_p75_bps

    def to_registry_amendment(self) -> dict:
        """JSON for doctrine_registry amendment: per-coin t1_walk_cadence /
        t2_excursion_bound rows with provenance, CI, cadence, owner."""
        rows = []
        for corridor, cc in sorted(self.coins.items()):
            rows.append({
                "name": f"t1_walk_cadence_s.{corridor}",
                "value": (T1_P50_MULTIPLIER * cc.p50_s) if cc.p50_s is not None
                         else None,
                "unit": "s",
                "state": cc.status,
                "n": cc.n, "n_events": cc.n_events, "n_censored": cc.n_censored,
                "p50_s": cc.p50_s,
                "ci_lo_s": cc.ci[0] if cc.ci else None,
                "ci_hi_s": cc.ci[1] if cc.ci else None,
                "provenance": self.provenance,
                "cadence": "14-day refresh",
                "owner": "S10.fill_tape_recorder",
            })
        return {"amendment_type": "s10_bounce_census",
                "provenance": self.provenance,
                "rows": rows}


# =============================================================== recorder =

class S10FillTapeRecorder:
    """The self-knowledge organ. Wire (README §GLUE):
      engine.py entry-fill site (~line 800):  recorder.register_fill(obs)
      engine.py on_depth_update (book.mid):   recorder.on_mid(sym, now_ns, mid)
      queue_broker cycle close:               recorder.settle(...)
      telemetry loop (markout_doctor cadence):recorder.flush(db_path)
    """

    MAX_PATH = 4000   # ~ (1800s horizon / 0.5s) bound on mid samples kept

    def __init__(self, bounce_target_default_bps: float =
                 DEFAULT_BOUNCE_TARGET_BPS):
        self._pending: dict = {}
        self._settled: list = []
        self._persisted_ids: set = set()
        self._target_default = float(bounce_target_default_bps)

    # -- live wiring ---------------------------------------------------------

    def register_fill(self, obs: FillObservation) -> None:
        self._pending[obs.fill_id] = obs

    def on_mid(self, corridor: str, ts_ns: int, mid_px: float) -> None:
        for obs in self._pending.values():
            if obs.corridor == corridor:
                obs.mid_path.append((int(ts_ns), float(mid_px)))
                if len(obs.mid_path) > self.MAX_PATH:
                    obs.mid_path = obs.mid_path[-self.MAX_PATH:]

    def settle(self, fill_id: str, exit_px: float, exit_ns: int,
               exit_tier: str, net_pnl_bps: Optional[float] = None) -> None:
        obs = self._pending.pop(fill_id, None)
        if obs is None:
            return
        obs.exit_px = float(exit_px)
        obs.exit_ns = int(exit_ns)
        obs.exit_tier = str(exit_tier)
        obs.net_pnl_bps = net_pnl_bps
        self._settled.append(obs)

    # -- evaluation -----------------------------------------------------------

    def _evaluate(self, obs: FillObservation) -> dict:
        """Markouts / adverse excursion / bounce onset for one settled fill."""
        row = {
            "fill_id": obs.fill_id, "corridor": obs.corridor,
            "ts_ns": obs.ts_ns, "side": obs.side, "entry_px": obs.entry_px,
            "exit_px": obs.exit_px, "exit_tier": obs.exit_tier,
            "adverse_excursion_bps": None, "bounce_onset_s": None,
            "regime_at_entry": obs.regime_at_entry,
            "shield_state_at_entry": obs.shield_state_at_entry,
            "bounce_target_bps": obs.bounce_target_bps,
            "censored": 1, "evidence_mode": "EXIT_BOUNDED",
            "provenance": "exit-bounded bootstrap",
        }
        for h in HORIZONS_S:
            row[f"markout_{int(h)}s_bps"] = None

        # exit-observed excursion fallback (from settle pnl vs mid-path min)
        if obs.net_pnl_bps is not None:
            row["adverse_excursion_bps"] = min(0.0, obs.net_pnl_bps)

        if obs.mid_path:
            row["evidence_mode"] = "MID_PATH"
            row["provenance"] = "live mid tape"
            # markouts at horizons (mid at or last before t_horizon)
            pts = sorted(obs.mid_path)
            worst = None
            onset = None
            target = obs.bounce_target_bps
            for (t_ns, px) in pts:
                mk = obs.markout_bps(px)
                if worst is None or mk < worst:
                    worst = mk
                if onset is None and mk >= target:
                    onset = (t_ns - obs.ts_ns) / 1e9
            for h in HORIZONS_S:
                th_ns = obs.ts_ns + int(h * 1e9)
                best = None
                for (t_ns, px) in pts:
                    if t_ns <= th_ns:
                        best = px
                    else:
                        break
                if best is not None:
                    row[f"markout_{int(h)}s_bps"] = obs.markout_bps(best)
            if worst is not None:
                row["adverse_excursion_bps"] = worst
            if onset is not None:
                row["bounce_onset_s"] = onset
                row["censored"] = 0
            return row

        # EXIT_BOUNDED mode (historical): favorable exit proves onset <= hold
        if obs.exit_ns is not None and obs.net_pnl_bps is not None:
            hold_s = (obs.exit_ns - obs.ts_ns) / 1e9
            if obs.net_pnl_bps >= obs.bounce_target_bps:
                row["bounce_onset_s"] = max(hold_s, 0.0)
                row["censored"] = 0
            else:
                row["bounce_onset_s"] = None
                row["censored"] = 1
        return row

    def evaluated_rows(self) -> list:
        return [self._evaluate(o) for o in self._settled]

    # -- persistence -----------------------------------------------------------

    def flush(self, db_path: str) -> int:
        """Append-only write of settled observations not yet persisted.
        Returns rows written. WAL + synchronous NORMAL per fleet DB spec.
        Idempotent: a second flush of the same observations writes nothing
        (B5 append-only discipline — no duplicate snapshots)."""
        rows = [self._evaluate(o) for o in self._settled
                if o.fill_id not in self._persisted_ids]
        if not rows:
            return 0
        conn = sqlite3.connect(db_path)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute(FILL_CENSUS_DDL)
            conn.execute(MARKOUT_SNAPSHOTS_DDL)
            cur = conn.cursor()
            for r in rows:
                cur.execute(
                    """INSERT OR IGNORE INTO fill_census (
                    fill_id, corridor, ts_ns, side, entry_px, exit_px,
                    exit_tier, adverse_excursion_bps, bounce_onset_s,
                    markout_1s_bps, markout_5s_bps, markout_30s_bps,
                    markout_60s_bps, markout_300s_bps, markout_1800s_bps,
                    regime_at_entry, shield_state_at_entry,
                    bounce_target_bps, evidence_mode, censored, provenance)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (r["fill_id"], r["corridor"], r["ts_ns"], r["side"],
                     r["entry_px"], r["exit_px"], r["exit_tier"],
                     r["adverse_excursion_bps"], r["bounce_onset_s"],
                     r["markout_1s_bps"], r["markout_5s_bps"],
                     r["markout_30s_bps"], r["markout_60s_bps"],
                     r["markout_300s_bps"], r["markout_1800s_bps"],
                     r["regime_at_entry"], r["shield_state_at_entry"],
                     r["bounce_target_bps"], r["evidence_mode"],
                     r["censored"], r["provenance"]))
                for h in HORIZONS_S:
                    cur.execute(
                        """INSERT INTO markout_snapshots (
                        fill_id, corridor, horizon_s, markout_bps, ts_ns)
                        VALUES (?,?,?,?,?)""",
                        (r["fill_id"], r["corridor"], h,
                         r[f"markout_{int(h)}s_bps"],
                         r["ts_ns"] + int(h * 1e9)))
            conn.commit()
            for r in rows:
                self._persisted_ids.add(r["fill_id"])
        finally:
            conn.close()
        return len(rows)

    # -- census ---------------------------------------------------------------

    def build_census(self, provenance: str = "S10.fill_tape_recorder") -> BounceCensus:
        coins = {}
        rows = self.evaluated_rows()
        by_coin = {}
        for r in rows:
            by_coin.setdefault(r["corridor"], []).append(r)
        for corridor, rs in by_coin.items():
            events = [r["bounce_onset_s"] for r in rs
                      if r["bounce_onset_s"] is not None]
            # censoring times: exit time (EXIT_BOUNDED) or last observed
            # mid-path sample, per settled observation with no bounce
            row_by_id = {r["fill_id"]: r for r in rs}
            censored_holds = []
            for o in self._settled:
                r = row_by_id.get(o.fill_id)
                if r is None or r["bounce_onset_s"] is not None:
                    continue
                if o.exit_ns is not None:
                    censored_holds.append(max(0.0,
                                              (o.exit_ns - o.ts_ns) / 1e9))
                elif o.mid_path:
                    last_ns = max(t for t, _ in o.mid_path)
                    censored_holds.append(max(0.0,
                                              (last_ns - o.ts_ns) / 1e9))
                else:
                    censored_holds.append(HORIZONS_S[-1])
            km = KaplanMeier(events, censored_holds)
            p50, ci_lo, ci_hi = km.median()
            ae_vals = [r["adverse_excursion_bps"] for r in rs
                       if r["adverse_excursion_bps"] is not None]
            ae_p75 = None
            if len(ae_vals) >= AE_MIN_N:
                ae_sorted = sorted(ae_vals)
                idx = int(round(0.75 * (len(ae_sorted) - 1)))
                ae_p75 = ae_sorted[idx]
            n = len(rs)
            if p50 is None:
                status = "NO_BOUNCE"
            elif (n >= CENSUS_MIN_N and ci_lo is not None and ci_hi is not None
                  and (ci_hi - ci_lo) <= CENSUS_MAX_CI_FRAC * max(p50, 1e-9)):
                status = "CENSUSED"
            else:
                status = "PROVISIONAL"
            coins[corridor] = CoinCensus(
                corridor=corridor, n=n, n_events=len(events),
                n_censored=len(censored_holds), p50_s=p50,
                ci=(ci_lo, ci_hi), ae_p75_bps=ae_p75, ae_n=len(ae_vals),
                status=status)
        return BounceCensus(coins, provenance=provenance)
