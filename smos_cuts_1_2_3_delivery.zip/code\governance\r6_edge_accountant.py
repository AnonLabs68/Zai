"""
SMOS V18 — CUT 3 / R6 EDGE ACCOUNTANT
=======================================
Codename: EdgeAccountant
Layer: L2 Cognition (R6)

PURPOSE
-------
R6 is the organ that keeps the fleet honest about itself. It maintains a
per-corridor Wilson/bootstrap edge ledger and publishes:
  PROVEN     → Wilson 95% LB > p* (breakeven)
  UNPROVEN   → n < 30 or LB not yet computable
  FALSIFIED  → Wilson 95% LB < p* → triggers GraduationGate demotion

The FALSIFIED pathway is the P4 falsification gate for the trading system itself.

DESIGN RECEIPTS (Z-AI)
-----------------------
- SZ-5: +8.8 / −36.5 payoff distribution demanded 80.6% WR breakeven.
  The flat p* = 0.5 is wrong for skewed payoff. p* must be computed
  per-corridor from its own realized win/loss USD distribution.
- V17 EdgeRadar Wilson-LB pattern: already proven in the graduation_gate.
  R6 extends it to the self-edge dimension (PROVEN/UNPROVEN/FALSIFIED),
  not just the graduation dimension.
- Fortress-cohort bootstrap LB = +3.17 bps at n=13 (task-42527) →
  already at the §13 target, reported PROVISIONAL until n=30.

SNIPE GATE
----------
R6 also maintains the snipe re-trial standing gate:
  lead_lag_snipe_mode stays OFF until the fortress cohort's Wilson LB
  exceeds the doctrine snipe_trial_wilson_lb_threshold.
  This prevents premature taker activation on an UNPROVEN cohort.

SHA-256 (this file): pending install verification
"""

from __future__ import annotations

import math
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

# ──────────────────────────────────────────────────────────────────────────────
# CONSTANTS (doctrine defaults; override from DoctrineRegistry at runtime)
# ──────────────────────────────────────────────────────────────────────────────
EDGE_MIN_N = 30                     # minimum fills for any verdict to leave UNPROVEN
WILSON_Z = 1.645                    # 95% one-sided
SNIPE_TRIAL_MIN_WILSON_LB = 0.0     # doctrine default: snipe stays OFF (0.0 = OFF)
FORTRESS_COHORT = {                 # bootstrap corpus from task-41752 receipts
    "GRAMUSDT", "ESPORTSUSDT", "RENDERUSDT", "DEXEUSDT",
    "ORCAUSDT", "APEUSDT", "CHZUSDT", "WOOUSDT", "RIVERUSDT",
}


class EdgeVerdict(str, Enum):
    PROVEN = "PROVEN"
    UNPROVEN = "UNPROVEN"
    FALSIFIED = "FALSIFIED"


# ──────────────────────────────────────────────────────────────────────────────
# DATA STRUCTURES
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class TradeOutcome:
    """One closed cycle contributing to a corridor's ledger."""
    cid: str
    net_pnl_usd: float
    pnl_bps: float
    is_win: bool              # net_pnl_usd > 0


@dataclass
class CorridorLedger:
    """Running win/loss ledger for one corridor."""
    symbol: str
    outcomes: List[TradeOutcome] = field(default_factory=list)

    @property
    def n(self) -> int:
        return len(self.outcomes)

    @property
    def wins(self) -> int:
        return sum(1 for o in self.outcomes if o.is_win)

    @property
    def total_wins_usd(self) -> float:
        return sum(o.net_pnl_usd for o in self.outcomes if o.is_win)

    @property
    def total_losses_usd(self) -> float:
        return abs(sum(o.net_pnl_usd for o in self.outcomes if not o.is_win))

    def breakeven_p_star(self) -> float:
        """
        p* = L / (W + L) where W = avg win USD, L = avg loss USD.
        Per-corridor from its own realized payoff distribution (SZ-5 receipt).
        Falls back to 0.5 if no wins or no losses yet.
        """
        n_wins = self.wins
        n_losses = self.n - n_wins
        if n_wins == 0 or n_losses == 0:
            return 0.5
        avg_w = self.total_wins_usd / n_wins
        avg_l = self.total_losses_usd / n_losses
        denominator = avg_w + avg_l
        if denominator <= 0:
            return 0.5
        return avg_l / denominator


@dataclass
class EdgeReport:
    """Published by R6 for consumption by L4 governance."""
    symbol: str
    verdict: EdgeVerdict
    n_fills: int
    win_rate: float
    wilson_lb: float          # Wilson 95% one-sided LB on win rate
    p_star: float             # breakeven win rate for this corridor's payoffs
    edge_bps_lb: float        # conservative edge estimate (bps, for scoreboard)
    is_provisional: bool      # True until n >= EDGE_MIN_N
    last_updated_ns: int


# ──────────────────────────────────────────────────────────────────────────────
# WILSON + BOOTSTRAP MATH
# ──────────────────────────────────────────────────────────────────────────────

def wilson_lb(wins: int, n: int, z: float = WILSON_Z) -> float:
    """Wilson 95% one-sided lower bound on win probability."""
    if n == 0:
        return 0.0
    p_hat = wins / n
    denom = 1.0 + z * z / n
    centre = (p_hat + z * z / (2 * n)) / denom
    margin = (z * math.sqrt(p_hat * (1.0 - p_hat) / n + z * z / (4 * n * n))) / denom
    return max(0.0, centre - margin)


def avg_pnl_lb(outcomes: List[TradeOutcome], z: float = WILSON_Z) -> float:
    """
    Conservative edge estimate as avg net bps minus z * stderr.
    Returns 0.0 if n < 2.
    """
    bps_vals = [o.pnl_bps for o in outcomes]
    n = len(bps_vals)
    if n < 2:
        return 0.0
    mean = sum(bps_vals) / n
    var = sum((x - mean) ** 2 for x in bps_vals) / (n - 1)
    stderr = math.sqrt(var / n)
    return mean - z * stderr


# ──────────────────────────────────────────────────────────────────────────────
# R6 EDGE ACCOUNTANT — TOP-LEVEL ORGAN
# ──────────────────────────────────────────────────────────────────────────────

class EdgeAccountant:
    """
    R6 — Self-performance estimator.

    Usage:
        accountant = EdgeAccountant(db_path)
        accountant.bootstrap_from_db()          # load historical fill tape
        accountant.record_cycle(symbol, cid, net_pnl_usd, pnl_bps)  # per fill
        report = accountant.get_report(symbol)  # EdgeReport with verdict
        fleet_verdict = accountant.fleet_verdict()  # fortress cohort aggregate
        snipe_armed = accountant.snipe_gate_open()  # True only if PROVEN
    """

    def __init__(self, db_path: str,
                 snipe_trial_lb_threshold: float = SNIPE_TRIAL_MIN_WILSON_LB):
        self._db_path = db_path
        self._snipe_lb_threshold = snipe_trial_lb_threshold
        self._ledgers: Dict[str, CorridorLedger] = defaultdict(
            lambda: CorridorLedger(symbol='UNKNOWN')
        )
        self._reports: Dict[str, EdgeReport] = {}

    def bootstrap_from_db(self) -> None:
        """
        Load historical trade cycles from SQLite at startup.
        Populates ledgers from the existing fill tape.
        """
        try:
            import sqlite3
            conn = sqlite3.connect(self._db_path, timeout=5.0)
            cur = conn.cursor()
            cur.execute("""
                SELECT cid, symbol, net_pnl_usd, pnl_bps
                FROM trade_cycles
                WHERE exit_ns IS NOT NULL
            """)
            rows = cur.fetchall()
            conn.close()
        except Exception:
            rows = []

        for cid, symbol, net_pnl_usd, pnl_bps in rows:
            net = float(net_pnl_usd or 0)
            bps = float(pnl_bps or 0)
            ledger = self._get_ledger(symbol)
            ledger.outcomes.append(TradeOutcome(
                cid=str(cid), net_pnl_usd=net, pnl_bps=bps,
                is_win=(net > 0)
            ))

        # Compute initial reports
        for sym in self._ledgers:
            self._reports[sym] = self._compute_report(sym)

    def record_cycle(self, symbol: str, cid: str,
                     net_pnl_usd: float, pnl_bps: float) -> EdgeReport:
        """
        Record one closed trade cycle. Returns the updated EdgeReport.
        Called by the engine on every PASSIVE_EXIT_HARVEST / CAT_STOP / etc.
        """
        ledger = self._get_ledger(symbol)
        ledger.outcomes.append(TradeOutcome(
            cid=cid, net_pnl_usd=net_pnl_usd, pnl_bps=pnl_bps,
            is_win=(net_pnl_usd > 0)
        ))
        report = self._compute_report(symbol)
        self._reports[symbol] = report
        return report

    def get_report(self, symbol: str) -> Optional[EdgeReport]:
        """Return the latest EdgeReport for a corridor."""
        if symbol not in self._reports:
            self._reports[symbol] = self._compute_report(symbol)
        return self._reports[symbol]

    def fleet_verdict(self) -> EdgeReport:
        """
        Aggregate EdgeReport across the fortress cohort.
        This is the primary snipe gate input.
        """
        all_outcomes: List[TradeOutcome] = []
        for sym in FORTRESS_COHORT:
            ledger = self._ledgers.get(sym)
            if ledger:
                all_outcomes.extend(ledger.outcomes)

        if not all_outcomes:
            return EdgeReport(
                symbol="FLEET_FORTRESS", verdict=EdgeVerdict.UNPROVEN,
                n_fills=0, win_rate=0.0, wilson_lb=0.0, p_star=0.5,
                edge_bps_lb=0.0, is_provisional=True,
                last_updated_ns=time.time_ns()
            )

        n = len(all_outcomes)
        wins = sum(1 for o in all_outcomes if o.is_win)
        wr = wins / n
        lb = wilson_lb(wins, n)
        # Aggregate p*
        n_wins = wins
        n_losses = n - wins
        avg_w = (sum(o.net_pnl_usd for o in all_outcomes if o.is_win) / max(n_wins, 1))
        avg_l = abs(sum(o.net_pnl_usd for o in all_outcomes if not o.is_win) / max(n_losses, 1))
        p_star = avg_l / (avg_w + avg_l) if (avg_w + avg_l) > 0 else 0.5

        edge_lb = avg_pnl_lb(all_outcomes)
        is_provisional = n < EDGE_MIN_N
        verdict = self._classify(lb, p_star, is_provisional)

        return EdgeReport(
            symbol="FLEET_FORTRESS", verdict=verdict,
            n_fills=n, win_rate=wr, wilson_lb=lb, p_star=p_star,
            edge_bps_lb=edge_lb, is_provisional=is_provisional,
            last_updated_ns=time.time_ns()
        )

    def snipe_gate_open(self) -> bool:
        """
        Returns True only if the fortress cohort's Wilson LB exceeds the
        doctrine snipe trial threshold. Default threshold = 0.0 = always OFF.
        Gate is the primary guardian against premature taker activation.
        """
        if self._snipe_lb_threshold <= 0.0:
            return False  # Doctrine: 0.0 = OFF unconditionally
        fleet = self.fleet_verdict()
        if fleet.is_provisional:
            return False
        return fleet.wilson_lb >= self._snipe_lb_threshold

    def summary(self) -> str:
        """Human-readable summary for startup banner / telemetry."""
        n_proven = sum(1 for r in self._reports.values()
                       if r.verdict == EdgeVerdict.PROVEN)
        n_unproven = sum(1 for r in self._reports.values()
                         if r.verdict == EdgeVerdict.UNPROVEN)
        n_falsified = sum(1 for r in self._reports.values()
                          if r.verdict == EdgeVerdict.FALSIFIED)
        fleet = self.fleet_verdict()
        return (
            f"R6 EdgeAccountant: {n_proven} PROVEN | {n_unproven} UNPROVEN | "
            f"{n_falsified} FALSIFIED | Fleet LB={fleet.wilson_lb:.3f} "
            f"p*={fleet.p_star:.3f} ({'PROV' if fleet.is_provisional else fleet.verdict.value})"
        )

    # ── Internal ──────────────────────────────────────────────────────────────

    def _get_ledger(self, symbol: str) -> CorridorLedger:
        if symbol not in self._ledgers:
            self._ledgers[symbol] = CorridorLedger(symbol=symbol)
        return self._ledgers[symbol]

    def _compute_report(self, symbol: str) -> EdgeReport:
        ledger = self._get_ledger(symbol)
        n = ledger.n
        wins = ledger.wins
        wr = wins / n if n > 0 else 0.0
        lb = wilson_lb(wins, n)
        p_star = ledger.breakeven_p_star()
        edge_lb = avg_pnl_lb(ledger.outcomes)
        is_provisional = n < EDGE_MIN_N
        verdict = self._classify(lb, p_star, is_provisional)

        return EdgeReport(
            symbol=symbol, verdict=verdict,
            n_fills=n, win_rate=wr, wilson_lb=lb, p_star=p_star,
            edge_bps_lb=edge_lb, is_provisional=is_provisional,
            last_updated_ns=time.time_ns()
        )

    def _classify(self, lb: float, p_star: float, is_provisional: bool) -> EdgeVerdict:
        if is_provisional:
            return EdgeVerdict.UNPROVEN
        if lb > p_star:
            return EdgeVerdict.PROVEN
        elif lb < p_star:
            return EdgeVerdict.FALSIFIED
        return EdgeVerdict.UNPROVEN
