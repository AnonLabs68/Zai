"""
SMOS V18 — CUT 3 / R6 EDGE ACCOUNTANT (the edge ledger organ)
=============================================================
Spec: COGNITIVE_STACK_SPEC.md §5 R6 SelfPerformanceEstimator ("the edge
accountant"), §8 G5 (graduation wiring — FALSIFIED feeds AMBER_HALVED
demotion via the EXISTING graduation_gate.py, never a re-implementation),
§11 Cut 3.

WHAT THIS ORGAN DOES
--------------------
Consumes closed trade cycles (the trade_cycles table / settle events) and
emits:
  - per-corridor edge ledger: n, win rate, Wilson 95% LB on win rate,
    mean bps, bootstrap-t 95% CI on mean bps, verdict
  - per-exit-tier performance (PASSIVE_MAKER_HARVEST / KINEMATIC_EJECT /
    CAT_STOP / timeouts) — ORGAN performance, not just trade performance
  - maker vs taker split (the taker ledger is the SNIPE re-litigation
    evidence base)
  - fortress-cohort scoreboard (the spec's top-level result metric:
    net bps/trade with Wilson LB against the +3 bps target)

PRE-REGISTERED VERDICT GATES (doctrine registry seeds, P5):
  PROVEN      n >= 20 AND bootstrap_lb(mean bps) > 0
  FALSIFIED   n >= 20 AND bootstrap_ub(mean bps) < 0
  UNPROVEN    otherwise (insufficient evidence — the default state)

SNIPE RE-TRIAL GATE (SZ-8 kill receipt, preserved):
  the taker path re-litigates ONLY IF mean drift >= +25 bps AND hit rate
  >= 60% AND n >= 100. Current taker n = 0 -> OFF, and this organ is the
  counter that will tell us if that ever changes.

Determinism: bootstrap uses a fixed seed and fixed B so ledger outputs are
reproducible byte-for-byte (B5 audit discipline).
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Optional

# ---- pre-registered gates (doctrine registry seeds) ------------------------
R6_MIN_N_VERDICT = 20          # cycles before PROVEN/FALSIFIED may fire
BOOTSTRAP_MIN_N = 8            # cycles before a mean-bps CI exists
BOOTSTRAP_B = 500
BOOTSTRAP_SEED = 42
WILSON_Z = 1.959964            # 95%

# scoreboard target (spec §13 scoreboard: Wilson 95% LB >= +3 bps)
FORTRESS_TARGET_WILSON_LB_BPS = 3.0

# SNIPE re-trial kill lines (SZ-8 receipt, pre-registered)
SNIPE_MIN_N = 100
SNIPE_MIN_DRIFT_BPS = 25.0
SNIPE_MIN_HIT_RATE = 0.60


def wilson_interval(k: int, n: int, z: float = WILSON_Z) -> tuple:
    """Wilson score interval for a binomial proportion. Returns (lo, hi)."""
    if n <= 0:
        return (0.0, 1.0)
    p = k / n
    denom = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / denom
    half = z * math.sqrt(max(0.0, p * (1.0 - p) / n + z * z / (4.0 * n * n))) / denom
    return (max(0.0, center - half), min(1.0, center + half))


@dataclass
class CycleRecord:
    corridor: str
    pnl_bps: float
    exit_tier: str
    is_taker: bool = False
    ts_ns: Optional[int] = None
    net_usd: Optional[float] = None


@dataclass
class CoinEdge:
    corridor: str
    n: int
    wins: int
    win_rate: float
    wilson_lb_win: float
    wilson_ub_win: float
    mean_bps: float
    boot_lb_bps: Optional[float]
    boot_ub_bps: Optional[float]
    verdict: str

    def as_dict(self) -> dict:
        return {
            "corridor": self.corridor, "n": self.n, "wins": self.wins,
            "win_rate": round(self.win_rate, 4),
            "wilson_lb_win": round(self.wilson_lb_win, 4),
            "wilson_ub_win": round(self.wilson_ub_win, 4),
            "mean_bps": round(self.mean_bps, 3),
            "boot_lb_bps": (None if self.boot_lb_bps is None
                            else round(self.boot_lb_bps, 3)),
            "boot_ub_bps": (None if self.boot_ub_bps is None
                            else round(self.boot_ub_bps, 3)),
            "verdict": self.verdict,
        }


class R6EdgeAccountant:

    def __init__(self):
        self.cycles: list = []

    def add_cycle(self, rec: CycleRecord) -> None:
        self.cycles.append(rec)

    def add_cycles(self, recs: list) -> None:
        for r in recs:
            self.add_cycle(r)

    # -- statistics -----------------------------------------------------------

    @staticmethod
    def _boot_ci(vals: list, seed: int = BOOTSTRAP_SEED,
                 b: int = BOOTSTRAP_B) -> tuple:
        """Percentile bootstrap 95% CI for the mean. Deterministic."""
        rng = random.Random(seed)
        n = len(vals)
        means = []
        for _ in range(b):
            sample = [vals[rng.randrange(n)] for _ in range(n)]
            means.append(sum(sample) / n)
        means.sort()
        lo = means[int(0.025 * (b - 1))]
        hi = means[int(0.975 * (b - 1))]
        return (lo, hi)

    @staticmethod
    def _verdict(n: int, boot: tuple) -> str:
        if n < R6_MIN_N_VERDICT or boot is None:
            return "UNPROVEN"
        if boot[0] > 0.0:
            return "PROVEN"
        if boot[1] < 0.0:
            return "FALSIFIED"
        return "UNPROVEN"

    # -- ledgers ---------------------------------------------------------------

    def coin_ledger(self) -> list:
        by_coin = {}
        for c in self.cycles:
            by_coin.setdefault(c.corridor, []).append(c)
        out = []
        for corridor in sorted(by_coin):
            cs = by_coin[corridor]
            vals = [c.pnl_bps for c in cs]
            n = len(cs)
            wins = sum(1 for v in vals if v > 0)
            lo, hi = wilson_interval(wins, n)
            boot = self._boot_ci(vals) if n >= BOOTSTRAP_MIN_N else None
            out.append(CoinEdge(
                corridor=corridor, n=n, wins=wins, win_rate=wins / n,
                wilson_lb_win=lo, wilson_ub_win=hi,
                mean_bps=sum(vals) / n,
                boot_lb_bps=boot[0] if boot else None,
                boot_ub_bps=boot[1] if boot else None,
                verdict=self._verdict(n, boot)))
        return out

    def tier_performance(self) -> list:
        by_tier = {}
        for c in self.cycles:
            by_tier.setdefault(c.exit_tier, []).append(c)
        out = []
        for tier in sorted(by_tier):
            cs = by_tier[tier]
            vals = [c.pnl_bps for c in cs]
            usd = [c.net_usd for c in cs if c.net_usd is not None]
            out.append({
                "exit_tier": tier, "count": len(cs),
                "mean_bps": round(sum(vals) / len(vals), 3),
                "share_of_exits": round(len(cs) / max(1, len(self.cycles)), 4),
                "net_usd": (round(sum(usd), 4) if usd else None),
            })
        return out

    def maker_taker_split(self) -> dict:
        maker = [c for c in self.cycles if not c.is_taker]
        taker = [c for c in self.cycles if c.is_taker]
        def _agg(cs):
            if not cs:
                return {"n": 0}
            vals = [c.pnl_bps for c in cs]
            wins = sum(1 for v in vals if v > 0)
            lo, hi = wilson_interval(wins, len(cs))
            return {"n": len(cs), "win_rate": round(wins / len(cs), 4),
                    "wilson_lb_win": round(lo, 4),
                    "mean_bps": round(sum(vals) / len(vals), 3)}
        return {"maker": _agg(maker), "taker": _agg(taker)}

    def snipe_retrial_status(self) -> dict:
        """SZ-8 kill receipt preserved as a standing gate. The taker path
        stays OFF until ALL three pre-registered lines clear."""
        taker = [c for c in self.cycles if c.is_taker]
        n = len(taker)
        if n == 0:
            return {"n_taker": 0, "mean_drift_bps": None, "hit_rate": None,
                    "eligible": False,
                    "lines": {"n": f"0/{SNIPE_MIN_N}",
                              "drift": f"-/{SNIPE_MIN_DRIFT_BPS:.0f}bps",
                              "hit": f"-/{SNIPE_MIN_HIT_RATE:.0%}"}}
        vals = [c.pnl_bps for c in taker]
        hits = sum(1 for v in vals if v > 0)
        mean_bps = sum(vals) / n
        hit_rate = hits / n
        eligible = (n >= SNIPE_MIN_N and mean_bps >= SNIPE_MIN_DRIFT_BPS
                    and hit_rate >= SNIPE_MIN_HIT_RATE)
        return {"n_taker": n, "mean_drift_bps": round(mean_bps, 3),
                "hit_rate": round(hit_rate, 4), "eligible": eligible,
                "lines": {
                    "n": f"{n}/{SNIPE_MIN_N}",
                    "drift": f"{mean_bps:.1f}/{SNIPE_MIN_DRIFT_BPS:.0f}bps",
                    "hit": f"{hit_rate:.0%}/{SNIPE_MIN_HIT_RATE:.0%}"}}

    def fortress_scoreboard(self, fortress: list) -> dict:
        """The spec's top-level result metric: cohort net bps/trade with
        Wilson LB vs the +3 bps target (scoreboard standard, SZ-7)."""
        cs = [c for c in self.cycles if c.corridor in fortress]
        if not cs:
            return {"n": 0}
        vals = [c.pnl_bps for c in cs]
        wins = sum(1 for v in vals if v > 0)
        n = len(vals)
        lo, _ = wilson_interval(wins, n)
        boot = self._boot_ci(vals) if n >= BOOTSTRAP_MIN_N else None
        return {
            "n": n, "win_rate": round(wins / n, 4),
            "wilson_lb_win": round(lo, 4),
            "mean_bps": round(sum(vals) / n, 3),
            "boot_lb_bps": (round(boot[0], 3) if boot else None),
            "target_wilson_lb_bps": FORTRESS_TARGET_WILSON_LB_BPS,
            "meets_bps_target": (boot is not None
                                 and boot[0] >= FORTRESS_TARGET_WILSON_LB_BPS),
        }

    def to_registry_amendment(self) -> dict:
        """FALSIFIED/PROVEN verdicts destined for graduation_gate (G5) and the
        doctrine registry. AMBER_HALVED demotion is applied by the EXISTING
        gate — this organ only emits evidence, never re-implements it."""
        return {
            "amendment_type": "r6_edge_ledger",
            "provenance": "R6.edge_accountant",
            "coins": [e.as_dict() for e in self.coin_ledger()],
            "tiers": self.tier_performance(),
            "maker_taker": self.maker_taker_split(),
            "snipe_retrial": self.snipe_retrial_status(),
        }
