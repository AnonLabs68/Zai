"""
SMOS V18 — CUT 1 ACCEPTANCE TESTS
==================================
Kill lines (pre-registered before running — SZ-4 discipline):
  - ALL 12 tests must pass. Any failure = Cut 1 does not ship.
  - T10 is THE acceptance: replaying task-41752 through the committee must
    reject HANA/APR, admit GRAM/ESPORTS/AT (+ MITO at ADMIT_MIN), and the
    admitted-set counterfactual must equal the fortress cohort's realized
    +$0.0842 (the same fills, minus the two thin books).
  - T11 totality/fail-closed: missing evidence => REJECT, never a guess.
  - T12: the P5 audit catalog must name >= 8 inline constants found in the
    SZ-8 code read (engine.py line-referenced).

Run: python test_cut1.py   (exit 0 = ship)
"""

import os
import sys
import tempfile

_this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _this_dir)
sys.path.insert(0, os.path.abspath(os.path.join(_this_dir, "..", "sovereign_fleet", "governance")))
sys.path.insert(0, os.path.abspath(os.path.join(_this_dir, "..")))

from doctrine_registry import DoctrineRegistry
from decision_journal import DecisionJournal
from admission_committee import (
    AdmissionCommittee, CorridorDossier, ADMIT, ADMIT_MIN, REJECT, RETIRE,
)
import fixtures_task41752 as fx

PASS, FAIL = "PASS", "FAIL"
_results = []


def check(name, cond, detail=""):
    _results.append((name, PASS if cond else FAIL, detail))
    print(f"[{PASS if cond else FAIL}] {name}"
          + (f"  -> {detail}" if detail else ""))


def main() -> int:
    tmp = tempfile.mkdtemp(prefix="cut1_")

    # ------------------------------------------------------------------ T01
    reg = DoctrineRegistry(os.path.join(tmp, "doctrine.db"))
    latest = reg.all_latest()
    check("T01 registry seed completeness (>=30 constants, provenance+"
          "cadence+owner)",
          len(latest) >= 30 and all(
              c.provenance and c.cadence and c.owner
              for c in latest.values()),
          f"{len(latest)} constants")

    # ------------------------------------------------------------------ T02
    v2 = reg.install("theta_l1_cushion_usd", 1200.0,
                     "census bootstrap n=20 corridors ( Cut 3 demo )",
                     "monthly-bootstrap", "research",
                     ci_lo=900.0, ci_hi=1600.0, amendment_ref="census-001")
    hist = reg.history("theta_l1_cushion_usd")
    check("T02 registry append-only versioning",
          v2 == 2 and len(hist) == 2 and hist[0].value == 1000.0
          and hist[1].value == 1200.0 and reg.value(
              "theta_l1_cushion_usd") == 1200.0,
          f"v{v2}, history={[h.value for h in hist]}")

    # ------------------------------------------------------------------ T03
    try:
        reg.get("nonexistent_constant")
        raised = False
    except KeyError:
        raised = True
    check("T03 unknown constant refuses inline fallback (P5)", raised)

    # ------------------------------------------------------------------ T04
    jr = DecisionJournal(os.path.join(tmp, "journal.db"))
    eid = jr.record_decision(
        corridor="GRAMUSDT", organ="G1.AdmissionCommittee",
        state_vector={"l1_usd": 4616.0, "tau_rel_bps": 6.5},
        action="ADMIT", rule_id="G1.R6",
        expected_outcome="fortress top-of-book: full ladder")
    oid = jr.resolve_outcome(eid, verdict="CONFIRMED", outcome_bps=16.04,
                             outcome_usd=0.0718)
    dec = jr.get_decision(eid)
    check("T04 journal append + outcome resolve",
          eid >= 1 and oid >= 1 and dec["action"] == "ADMIT"
          and dec["state_vector"]["l1_usd"] == 4616.0)

    # ------------------------------------------------------------------ T05
    try:
        jr.resolve_outcome(eid, verdict="DOUBLE", outcome_bps=1.0)
        blocked = False
    except RuntimeError:
        blocked = True
    check("T05 outcome double-resolve blocked (append-only, B5)", blocked)

    # ------------------------------------------------------------------ T06
    # fresh registry for committee tests (no demo amendment)
    reg2 = DoctrineRegistry(os.path.join(tmp, "doctrine2.db"))
    jr2 = DecisionJournal(os.path.join(tmp, "journal2.db"))
    committee = AdmissionCommittee(reg2, jr2)

    def dossier(sym, **over):
        p = fx.DEPTH_PROFILES[sym]
        base = dict(symbol=sym, tau_rel_bps=p["tau_rel_bps"],
                    l1_usd=p["l1_usd"], l3_min_cum_usd=p["l3_min_cum_usd"],
                    resilience_class=p["resilience_class"],
                    volume_24h_usd=p["volume_24h_usd"])
        base.update(over)
        return CorridorDossier(**base)

    d_gram = committee.evaluate(dossier("GRAMUSDT"))
    check("T06 GRAM -> ADMIT (CUSHION_L1)",
          d_gram.action == ADMIT and d_gram.rule_id == "G1.R6",
          f"{d_gram.action} via {d_gram.rule_id} ({d_gram.cause})")

    # ------------------------------------------------------------------ T07
    d_esp = committee.evaluate(dossier("ESPORTSUSDT"))
    d_at = committee.evaluate(dossier("ATUSDT"))
    check("T07 ESPORTS + AT -> ADMIT",
          d_esp.action == ADMIT and d_at.action == ADMIT,
          f"ESPORTS={d_esp.action}/{d_esp.rule_id}, "
          f"AT={d_at.action}/{d_at.rule_id}")

    # ------------------------------------------------------------------ T08
    d_mito = committee.evaluate(dossier("MITOUSDT"))
    check("T08 MITO -> ADMIT_MIN (the counterexample branch: $271 L1, "
          "L3+resilient)",
          d_mito.action == ADMIT_MIN and d_mito.rule_id == "G1.R7",
          f"{d_mito.action} via {d_mito.rule_id} ({d_mito.cause})")

    # ------------------------------------------------------------------ T09
    d_hana = committee.evaluate(dossier("HANAUSDT"))
    d_apr = committee.evaluate(dossier("APRUSDT"))
    check("T09 HANA + APR -> REJECT (CUSHION_FAIL — the bleed pair)",
          d_hana.action == REJECT and d_hana.rule_id == "G1.R8"
          and d_apr.action == REJECT and d_apr.rule_id == "G1.R8",
          f"HANA={d_hana.cause} | APR={d_apr.cause}")

    # ------------------------------------------------------------------ T10
    # THE acceptance replay
    all_syms = list(fx.DEPTH_PROFILES.keys())
    decisions = committee.evaluate_fleet([dossier(s) for s in all_syms])
    admitted = [s for s, dec in decisions.items()
                if dec.action in (ADMIT, ADMIT_MIN)]
    cf = fx.counterfactual(admitted)
    expected = fx.EXPECTED_COHORT_NETS["fortress"]
    check("T10 task-41752 counterfactual replay: admitted set == fortress "
          "cohort net (+$0.0842)",
          set(admitted) == {"GRAMUSDT", "ESPORTSUSDT", "MITOUSDT", "ATUSDT"}
          and abs(cf - expected) <= 0.001,
          f"admitted={sorted(admitted)} counterfactual=${cf:+.4f} "
          f"(run realized ${fx.EXPECTED_COHORT_NETS['run_total']:+.4f})")

    # ------------------------------------------------------------------ T11
    d_missing = committee.evaluate(CorridorDossier(symbol="NEWUSDT"))
    check("T11 fail-closed on missing evidence (G1.R1) + totality",
          d_missing.action == REJECT
          and d_missing.rule_id == "G1.R1"
          and "EVIDENCE_MISSING" in d_missing.cause
          and len(decisions) == len(all_syms),
          d_missing.cause)

    # ------------------------------------------------------------------ T12
    audit = reg2.audit_inline()
    check("T12 P5 inline-constant audit names >= 8 code-read violations",
          len(audit) >= 8 and all("site" in a and "governs" in a
                                  for a in audit),
          f"{len(audit)} violations catalogued "
          f"(first: {audit[0]['const']} @ {audit[0]['site']})")

    # ------------------------------------------------------------------ 
    n_pass = sum(1 for (_, s, _) in _results if s == PASS)
    print("\n" + "=" * 60)
    print(f"CUT 1 ACCEPTANCE: {n_pass}/{len(_results)} PASS")
    if n_pass == len(_results):
        print("VERDICT: SHIP (all kill lines cleared)")
    else:
        print("VERDICT: DO NOT SHIP (kill line tripped)")
    for (n, s, d) in _results:
        if s == FAIL:
            print(f"  FAILED: {n} -> {d}")
    return 0 if n_pass == len(_results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
