"""
SMOS V18 — CUT 1 / G1 ADMISSION COMMITTEE (v0)
===============================================
The organ that task-41752 proved was missing: corridor_depth_profiles.json
held HANA $153 / APR $408 L1 BEFORE the first order was placed — measured,
never enforced. This committee is the enforcement.

LATTICE (precedence-ordered, first match wins — COGNITIVE_STACK_SPEC §7.1):

  G1.R1  EVIDENCE_MISSING   -> REJECT     (fail-closed: no critical field, no quote)
  G1.R2  TICK_CLASS         -> REJECT     (tau_rel outside Class II band [4.0, 10.5])
  G1.R3  VOL_FLOOR          -> REJECT     (volume < $2M/day pre-registered floor)
  G1.R4  TICK_LATCH         -> REJECT     (tick change latched — WP-A death mode)
  G1.R5  AGE_BUDGET         -> RETIRE     (>= 270 x 8h windows — KM half-life)
  G1.R6  CUSHION_L1         -> ADMIT      (L1 >= theta_L1: fortress cushion)
  G1.R7  CUSHION_L3_RESILIENT -> ADMIT_MIN (L3 >= theta_L3 AND resilience class
                                            RESILIENT — the MITO counterexample
                                            branch: thin L1, deep+resilient L3,
                                            single slot, min clip)
  G1.R8  CUSHION_FAIL       -> REJECT     (thin AND fragile — HANA/APR class)

THE MITO LAW: a single flat L1 line ($1,500 proposed) would have excluded
MITO ($271 L1, net-positive on task-41752) while admitting AT ($2,556 L1,
net-negative). Cushion is a LATTICE, not a line. The L3+resilience branch
is what admits MITO honestly; the fragility flag is what rejects APR
($408 L1, $4,790 L3 — L3 alone would have passed it: the two-dimensional
test is load-bearing).

ALL thresholds come from the DoctrineRegistry (L3). Nothing is inline.
Every decision is journal-logged (L6) with its full evidence vector.

Integration target:
  sovereign_fleet/governance/admission_committee.py  (verbatim)
  Called at run_sovereign_fleet() startup for every CORRIDOR_CONFIGS entry,
  and on every UniverseScreenerDaemon candidate emission.

Stdlib only. Zero fleet dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

try:
    from doctrine_registry import DoctrineRegistry
    from decision_journal import DecisionJournal
except ImportError:
    from sovereign_fleet.governance.doctrine_registry import DoctrineRegistry
    from sovereign_fleet.governance.decision_journal import DecisionJournal

# Critical evidence — a corridor missing ANY of these fails closed (G1.R1).
CRITICAL_FIELDS = (
    "tau_rel_bps", "l1_usd", "l3_min_cum_usd", "resilience_class",
    "volume_24h_usd",
)

RESILIENCE_OK = {"RESILIENT", "FORTRESS"}

ADMIT, ADMIT_MIN, REJECT, RETIRE = "ADMIT", "ADMIT_MIN", "REJECT", "RETIRE"


@dataclass
class CorridorDossier:
    """Evidence bundle for one corridor — measured, never guessed."""
    symbol: str
    tau_rel_bps: Optional[float] = None
    l1_usd: Optional[float] = None
    l3_min_cum_usd: Optional[float] = None
    resilience_class: Optional[str] = None       # FORTRESS/RESILIENT/FRAGILE
    volume_24h_usd: Optional[float] = None
    funding_bps: Optional[float] = None
    tick_latch: bool = False
    age_windows: float = 0.0
    r_isolation: Optional[float] = None
    wilson_lb: Optional[float] = None
    n_exits: int = 0
    provenance: Dict[str, str] = field(default_factory=dict)

    def evidence_vector(self) -> Dict:
        return {
            "tau_rel_bps": self.tau_rel_bps, "l1_usd": self.l1_usd,
            "l3_min_cum_usd": self.l3_min_cum_usd,
            "resilience_class": self.resilience_class,
            "volume_24h_usd": self.volume_24h_usd,
            "funding_bps": self.funding_bps,
            "tick_latch": self.tick_latch, "age_windows": self.age_windows,
            "r_isolation": self.r_isolation, "wilson_lb": self.wilson_lb,
            "n_exits": self.n_exits,
        }


@dataclass
class AdmissionDecision:
    symbol: str
    action: str          # ADMIT | ADMIT_MIN | REJECT | RETIRE
    rule_id: str
    cause: str
    evidence: Dict
    expected_outcome: str
    event_id: Optional[int] = None   # journal reference


class AdmissionCommittee:
    """G1: consumes measured dossiers, emits journal-logged admission
    decisions. Decides nothing from anecdotes; every threshold is doctrine."""

    def __init__(self, registry: DoctrineRegistry,
                 journal: Optional[DecisionJournal] = None):
        self.reg = registry
        self.journal = journal

    # -- lattice ------------------------------------------------------------
    def evaluate(self, d: CorridorDossier) -> AdmissionDecision:
        ev = d.evidence_vector()

        # G1.R1 — fail-closed on missing critical evidence
        missing = [f for f in CRITICAL_FIELDS if ev.get(f) is None]
        if missing:
            return self._emit(d, REJECT, "G1.R1",
                              f"EVIDENCE_MISSING:{','.join(missing)}", ev,
                              "no quote until the dossier is complete "
                              "(fail-closed)")

        # G1.R2 — tick class (the fee-wall law)
        lo = self.reg.value("tau_rel_class2_lo_bps")
        hi = self.reg.value("tau_rel_class2_hi_bps")
        if not (lo <= d.tau_rel_bps <= hi):
            return self._emit(d, REJECT, "G1.R2",
                              f"TICK_CLASS:{d.tau_rel_bps:.2f}bps outside "
                              f"[{lo:.1f},{hi:.1f}]", ev,
                              "Class I/III tick economics rejected "
                              "(RESEARCH-1)")

        # G1.R3 — pre-registered volume floor
        floor = self.reg.value("volume_floor_usd")
        if d.volume_24h_usd < floor:
            return self._emit(d, REJECT, "G1.R3",
                              f"VOL_FLOOR:{d.volume_24h_usd:.0f} < "
                              f"{floor:.0f}", ev,
                              "capacity starvation risk (SZ-3)")

        # G1.R4 — tick change latch (WP-A death mode: 37% re-tick)
        if d.tick_latch:
            return self._emit(d, REJECT, "G1.R4", "TICK_LATCH_SET", ev,
                              "tick change latched — corridor economics "
                              "re-census required before quoting (WP-A)")

        # G1.R5 — age budget (WP-A KM half-life)
        budget = self.reg.value("wpa_age_budget_windows")
        if d.age_windows >= budget:
            return self._emit(d, RETIRE, "G1.R5",
                              f"AGE_BUDGET:{d.age_windows:.0f} >= "
                              f"{budget:.0f}", ev,
                              "hard age stop — rotate, do not quote (WP-A)")

        # G1.R6 — fortress cushion at the top of book
        theta_l1 = self.reg.value("theta_l1_cushion_usd")
        if d.l1_usd >= theta_l1:
            return self._emit(d, ADMIT, "G1.R6",
                              f"CUSHION_L1:{d.l1_usd:.0f} >= "
                              f"{theta_l1:.0f}", ev,
                              "fortress top-of-book: full ladder, standard "
                              "slots")

        # G1.R7 — the MITO branch: deep + resilient, thin top
        theta_l3 = self.reg.value("theta_l3_cushion_usd")
        if (d.l3_min_cum_usd >= theta_l3
                and d.resilience_class in RESILIENCE_OK):
            return self._emit(d, ADMIT_MIN, "G1.R7",
                              f"CUSHION_L3_RESILIENT:{d.l3_min_cum_usd:.0f}"
                              f" >= {theta_l3:.0f} & "
                              f"{d.resilience_class}", ev,
                              "single slot, minimum clip, graduated-shield "
                              "mandatory — thin L1, resilient depth")

        # G1.R8 — thin and fragile
        return self._emit(d, REJECT, "G1.R8",
                          f"CUSHION_FAIL:L1 {d.l1_usd:.0f} < "
                          f"{theta_l1:.0f}; L3 {d.l3_min_cum_usd:.0f} "
                          f"{'<' if d.l3_min_cum_usd < theta_l3 else '>='} "
                          f"{theta_l3:.0f} / {d.resilience_class}", ev,
                          "thin book: sweeps traverse resting rungs "
                          "(task-41752 HANA/APR receipts)")

    # -- journaling ---------------------------------------------------------
    def _emit(self, d: CorridorDossier, action: str, rule_id: str,
              cause: str, ev: Dict, expected: str) -> AdmissionDecision:
        event_id = None
        if self.journal is not None:
            state = dict(ev)
            state["cause"] = cause
            event_id = self.journal.record_decision(
                corridor=d.symbol, organ="G1.AdmissionCommittee",
                state_vector=state, action=action, rule_id=rule_id,
                expected_outcome=expected)
        return AdmissionDecision(d.symbol, action, rule_id, cause, ev,
                                 expected, event_id)

    # -- fleet pass ---------------------------------------------------------
    def evaluate_fleet(self, dossiers: List[CorridorDossier]
                       ) -> Dict[str, AdmissionDecision]:
        """Totality guarantee: every dossier resolves to exactly one action
        (the lattice's terminal rule G1.R8 has no exit condition)."""
        out: Dict[str, AdmissionDecision] = {}
        for d in dossiers:
            dec = self.evaluate(d)
            if d.symbol in out:
                raise RuntimeError(
                    f"totality violation: duplicate dossier {d.symbol}")
            out[d.symbol] = dec
        return out
