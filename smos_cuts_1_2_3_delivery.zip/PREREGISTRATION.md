# CUT 2 / CUT 3 — PRE-REGISTERED KILL LINES & SCOREBOARD RULES (v1.0)

**Provenance:** external peer review of the SZ-9 Cut 2/3 delivery flagged — correctly —
that the Cut 2 acceptance criterion was restructured post-hoc after observed failures
(worklog SZ-9: "3 iterations, each failure a real insight"). Each insight is defensible;
the process is still a P4 foul, because "the restructure was justified" is unfalsifiable
after the fact. Per the review's remedy and M2/M5 discipline, this file freezes the
FINAL criterion BEFORE any real-tape replay runs.

**Status: PRE-REGISTERED 2026-10-02. No real-tape Cut 2 result existed at freeze time
(pipe re-checked at freeze: commit 0c03391 unchanged, task-42527 telemetry not pushed).**

Amendments to anything below require a versioned amendment with this file attached.
Inline edits are unconstitutional.

---

## A. CUT 2 — BINDING KILL LINES (run on user's box, after splicing `shield_dt_patch.py`)

ALL five must pass for acceptance. Any failure = acceptance RED: report red, no live
trust; `tau=2.0 s` and the z-bands (2 / 3) go to amendment review before the shield's
escalation ladder is trusted for live decisions.

1. **Sustained-regime cross-rate z gap** — 2/20/50 Hz views of the APR-calibrated step
   (-60 bps/s for 1.5 s), t >= 20.5 s: post-patch gap **<= 1.0 sigma-unit**.
   (Synthetic receipt at freeze: 0.73.)
2. **Quiet regime** — pure sine input, every rate: **zero** band-1 escalations.
3. **Stochastic burst tier** — time-to-band-2 spread **<= 0.1 s** across rates;
   worst-z spread **<= 0.5 sigma**. (Synthetic receipts at freeze: 0.000 s / 0.33.)
4. **APR 17:39:54 numeric replay on the real pre-fill depth trace**: rungs 2/3
   (fills at 0.1315 / 0.1316) never post; rung 1 clipped or retreat-armed.
   (Structural pass already receipted in AUDIT.md §5; the numeric run was honestly
   scoped as owed — it is owed still, and it binds here.)
5. **`tau = 2.0 s` stays PROVISIONAL** — re-derivation only via census evidence
   (n >= 30 on >= 1 corridor), per AUDIT.md §6 disposition.

*Precision note:* the residual quoted as "0.35" in the review corresponds to receipts
of 0.73 sigma (sustained step gap) and 0.33 sigma (stochastic worst-z spread). Both
are expected non-zero (onset ambiguity at coarse rates + finite-sample EWMA noise).
The bound, not the explanation, is the criterion. Explanations do not gate; numbers do.

## B. SCOREBOARD RULES (R6 headline organ, effective immediately)

1. **Headline = bootstrap CI on mean bps per cycle + Wilson LB.** Win rate is a
   diagnostic field, never a headline, never quoted alone.
2. **Mandatory tail-stress line** on every session report: session PnL re-stated with
   the worst historical CAT_STOP (-140 bps, HANA incident) replayed into the sample.
3. **The +3.17 bps / n=13 bootstrap LB is a smoke test** — it rules out gross negative
   edge at current size and nothing else. Stays below every verdict gate; never quoted
   as progress.
4. **The task-42527 session** (17/22, +99.3 bps on $15): Wilson 95% CI on WR is
   56.6-89.9%; expectancy point estimate ~+4.5 bps/cycle at n=22 with CI straddling
   zero; session was tail-free (zero drawdown). Quoted only with these three riders.

## C. CALIBRATION PROVENANCE RULES (S10 census)

1. **The 37% selection-bias figure is a certification-fixture receipt** — one draw,
   n=400, 50% censoring. Only the direction is robust (naive drop-the-censored biases
   the bounce median LOW, making toxic corridors look like fast bouncers). Live
   magnitude comes from the census; the figure is never quoted as a market constant.
2. **Clip-size provenance**: FillObservation already records `qty`; every census
   amendment carries the clip-size distribution in provenance. A $15 clip on a
   $150-400 L1 corridor rides front-of-queue — bounce-onset quantiles from this tape
   are size-bucket-0 quantiles, not scale-free ones.
3. **Size-up is a separate pre-registered experiment** with its own kill lines —
   never a parameter edit.
4. **task-42527 receipts are user-relayed until the DB export lands in the pipe.**
   Byte-level verification owed on push (M1/M2 applied to ourselves, not doubt of
   the operator).

## D. STANDING ANSWER ON FILL PROVENANCE

task-42527 is live micro-stake: $15 active principal, real venue, real maker fills
and fees; the corridor-depth profiles are pre-quote snapshots of the live book. Cut 3
therefore calibrates against real queue position and real adverse selection — not a
simulator's fill model — with the size-bucket caveat of C.2 attached. Retirement
remains interlocked: n >= 30 AND CI-width <= 50% of P50 before any corridor leaves
the flat timeout; EXIT_BOUNDED onsets are upper bounds, so errors fail toward the
incumbent. Zero behavior change until earned.
