"""
SMOS V18 — CUT 1 / TASK-41752 REPLAY FIXTURE
=============================================
Acceptance data frozen verbatim from the 28.2-minute 20-corridor live run
(task-41752, 23 fills, $25 pool, net -$0.2098). Source: the user-relayed
telemetry tables + recordings/corridor_depth_profiles.json probe output.

This fixture exists so the committee's acceptance test is a REPLAY of a real
incident, not a unit test of expected inputs (COGNITIVE_STACK_SPEC §11 Cut 1:
'Replay task-41752: HANA/APR rejected, GRAM/ESPORTS/MITO/AT admitted; net
flips to +$0.084').

Provenance notes (honest):
  - Depth (L1 / min-cum L3) and resilience classes: measured by the local
    AI's probe of recordings/corridor_depth_profiles.json during task-41752.
  - tau_rel: GRAM 6.5 bps derived from its printed quote grid (0.001 / 1.528);
    others carry corridor-registry cfg defaults (~8.0 bps) — flagged in
    provenance, real per-coin census pending (Cut 3).
  - volume_24h_usd: corridor cfg default (6M) — real EWMA census pending
    (Cut 3). The replay's discriminating dimensions are cushion + resilience,
    which were measured.
  - CYCLES: symbol -> list of (net_pnl_usd,) per closed fill, exactly as
    printed in the task-41752 itemization. Cohort sums verified:
    fortress (GRAM+ESPORTS+MITO+AT) = +$0.0842; thin (HANA+APR) = -$0.2941.
"""

from typing import Dict, List, Tuple

# (l1_usd, l3_min_cum_usd, resilience_class, tau_rel_bps, volume_24h_usd,
#  provenance-note)
DEPTH_PROFILES: Dict[str, Dict] = {
    "GRAMUSDT": {
        "l1_usd": 4616.0, "l3_min_cum_usd": 28967.0,
        "resilience_class": "FORTRESS", "tau_rel_bps": 6.5,
        "volume_24h_usd": 6_000_000.0,
        "note": "measured task-41752 depth probe; tau derived from grid"},
    "ESPORTSUSDT": {
        "l1_usd": 2683.0, "l3_min_cum_usd": 7915.0,
        "resilience_class": "FORTRESS", "tau_rel_bps": 8.0,
        "volume_24h_usd": 6_000_000.0,
        "note": "measured L1/L3; tau = cfg default pending census"},
    "MITOUSDT": {
        "l1_usd": 271.0, "l3_min_cum_usd": 3125.0,
        "resilience_class": "RESILIENT", "tau_rel_bps": 8.0,
        "volume_24h_usd": 6_000_000.0,
        "note": "the counterexample: $271 L1, net-positive on the run"},
    "ATUSDT": {
        "l1_usd": 2556.0, "l3_min_cum_usd": 4055.0,
        "resilience_class": "RESILIENT", "tau_rel_bps": 8.0,
        "volume_24h_usd": 6_000_000.0,
        "note": "measured; net-negative on the run but cushion-passing — "
                "edge accounting is R6/G5 business, not G1's"},
    "HANAUSDT": {
        "l1_usd": 153.0, "l3_min_cum_usd": 1557.0,
        "resilience_class": "FRAGILE", "tau_rel_bps": 8.0,
        "volume_24h_usd": 6_000_000.0,
        "note": "the sweep receipt: $153 L1, -140.73 bps CAT_STOP"},
    "APRUSDT": {
        "l1_usd": 408.0, "l3_min_cum_usd": 4790.0,
        "resilience_class": "FRAGILE", "tau_rel_bps": 8.0,
        "volume_24h_usd": 6_000_000.0,
        "note": "the waterfall receipt: $408 L1, 3 rungs into a waterfall "
                "twice in 74s; L3 alone would have passed a naive line"},
}

# Closed trade cycles per symbol, net USD, in exit order — verbatim from the
# task-41752 itemization (23 fills).
CYCLES: Dict[str, List[Tuple[float]]] = {
    "GRAMUSDT": [(0.0083,), (0.0117,), (0.0294,), (0.0015,), (0.0049,),
                 (0.0159,)],
    "MITOUSDT": [(-0.0064,), (0.0078,)],
    "ESPORTSUSDT": [(0.0120,)],
    "ATUSDT": [(-0.0018,), (0.0078,), (-0.0051,), (-0.0019,)],
    "APRUSDT": [(-0.0032,), (-0.0054,), (-0.0018,), (-0.0126,), (-0.0090,),
                (-0.0107,), (-0.0499,), (-0.0462,), (-0.0839,)],
    "HANAUSDT": [(-0.0712,)],
}

EXPECTED_COHORT_NETS = {
    "fortress": +0.0842,   # GRAM + ESPORTS + MITO + AT
    "thin": -0.2941,       # HANA + APR
    "run_total": -0.2098,
}


def cohort_net(symbols: List[str]) -> float:
    return round(sum(c[0] for s in symbols for c in CYCLES[s]), 4)


def counterfactual(admitted: List[str]) -> float:
    """Net USD of the run had ONLY the admitted corridors been quoted."""
    return cohort_net(admitted)
